<aside class="sidebar" role="navigation">
            <div class="scroll-sidebar">
                <div class="user-profile">
                    <div class="dropdown user-pro-body">
                        <div class="profile-image">
                            <img src="<?php echo base_url('assets/plugins/images/logo.jfif')?>" alt="user-img" class="img-circle">
                            <a href="javascript:void(0);" class="dropdown-toggle u-dropdown text-blue" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                                <span class="badge badge-danger">
                                    <i class="fa fa-angle-down"></i>
                                </span>
                            </a>
<!--                            <ul class="dropdown-menu animated flipInY">  
                                <li><a href="<?php // echo base_url('Welcome/logout') ?>"><i class="fa fa-power-off"></i> Logout</a></li>
                            </ul>-->
                        </div>
                        <p class="profile-text m-t-15 font-16"><a href="javascript:void(0);"> <?php if(isset($_SESSION['name'])) { echo $_SESSION['name'];} else { echo ''; }?></a></p>
                    </div>
                </div>
                <nav class="sidebar-nav">
                    <ul id="side-menu">
                          <?php // print_r($_SESSION);exit;
                          if(isset($_SESSION['role']) && $_SESSION['role']=='D'){?>
                        <li>
                            <a class="waves-effect" href="<?php echo base_url("patients/index")?>" aria-expanded="false"><i class="icon-notebook fa-fw"></i> <span class="hide-menu"> Register Patients </span></a>
                             
                        </li>
                        <li>
                            <a class="waves-effect" href="<?php echo base_url("patients/search_patients")?>" aria-expanded="false"><i class="icon-magnifier fa-fw"></i> <span class="hide-menu"> Search Patients </span></a>
                             
                        </li>
                          <?php } else if(isset($_SESSION['role']) && ($_SESSION['role'])=='POS'){?>
                        <li>
                            <a class="waves-effect" href="<?php echo base_url("pos/search_prescription")?>" aria-expanded="false"><i class="icon-magnifier fa-fw"></i> <span class="hide-menu"> Search Prescription </span></a>
                             
                        </li>
                        <li>
                            <a class="waves-effect" href="<?php echo base_url("pos/pharmacy_bills")?>" aria-expanded="false"><i class="icon-magnifier fa-fw"></i> <span class="hide-menu"> Search Bills </span></a>
                             
                        </li>
                          <?php } else if(isset($_SESSION['role']) && ($_SESSION['role'])=='P'){ ?>
                         <li>
                            <!--<a class="waves-effect" href="<?php // echo base_url("pos/pharmacy_bills")?>" aria-expanded="false"><i class="icon-magnifier fa-fw"></i> <span class="hide-menu"> Approve Doctors</span></a>-->
                          <a class="waves-effect" href="<?php echo base_url("pmdc/pending_approvals_list")?>" aria-expanded="false"><i class="icon-magnifier fa-fw"></i> <span class="hide-menu"> Approve Doctors</span></a>
                          
                        </li>
                          <?php } else if(isset($_SESSION['role']) && ($_SESSION['role'])=='N'){?>
                        <li>
                            <a class="waves-effect" href="<?php echo base_url("patients/index")?>" aria-expanded="false"><i class="icon-notebook fa-fw"></i> <span class="hide-menu"> Register Patients </span></a>
                             
                        </li>
                        <li>
                            <a class="waves-effect" href="<?php echo base_url("patients/search_patients")?>" aria-expanded="false"><i class="icon-magnifier fa-fw"></i> <span class="hide-menu"> Search Patients </span></a>
                             
                        </li>
                          <?php } else if(isset($_SESSION['role']) && ($_SESSION['role'])=='FD'){?>
                        <li>
                            <a class="waves-effect" href="<?php echo base_url("patients/index")?>" aria-expanded="false"><i class="icon-notebook fa-fw"></i> <span class="hide-menu"> Register Patients </span></a>
                             
                        </li>
                        <li>
                            <a class="waves-effect" href="<?php echo base_url("patients/search_patients")?>" aria-expanded="false"><i class="icon-magnifier fa-fw"></i> <span class="hide-menu"> Search Patients </span></a>
                             
                        </li>
                          <?php }?>
                        <?php if(isset($_SESSION['role']) && ($_SESSION['role'])!=''){?>  
                        <li>
                            <a style="margin-top:.75em;margin-bottom:.75em;width: 45%; height: 50px; font-size: 15px; float:left; margin-left: 5%;" href="<?php echo base_url('Welcome/logout') ?>"><i class="fa fa-power-off"></i> Logout</a>                             
                            
                            <a style="margin-top:.75em;margin-bottom:.75em;width: 45%; height: 50px; font-size: 15px; float:right; margin-right: 5%;" href="<?php echo base_url('welcome/password_reset') ?>"><i class="fa fa-power-off"></i> Reset</a>
                            
                        </li>
                        <?php }
                        else {?>
                        <li>
                            <a style="margin-top:.75em;margin-bottom:.75em;width: 45%; height: 50px; font-size: 17px; float:left; margin-left: 5%;" href="<?php echo base_url('Welcome/logout') ?>"><i class="fa fa-arrow-circle-left"></i> Back</a>
                        </li>
                        <?php } ?>
                    </ul>
                </nav> 
            </div>
        </aside>