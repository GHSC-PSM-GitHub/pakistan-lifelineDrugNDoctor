<?php include 'header.php'; ?>
<?php echo $main_content; ?>
<?php
include 'footer.php';
if ($this->router->fetch_class() == "patients") {
//    print_r(base_url());exit;
     include "ajax_files/patients_js.php";
}
else if($this->router->fetch_class() == "pos"){
    include "ajax_files/pos_js.php";
}
else if($this->router->fetch_class() == "pmdc"){
    include "ajax_files/pmdc_js.php";
}
else if($this->router->fetch_class() == "welcome"){
    include "ajax_files/signup_js.php";
}
 ?>