<script>
    $(function () {

        $('#search_table').DataTable({
            dom: 'Bfrtip',
            buttons: [
                'copy', 'csv', 'excel', 'pdf', 'print'
            ]
        });
        $('div.dataTables_filter input').addClass('col-md-4 form-control');
        $('div.dataTables_filter input').css("width", "100%");
        $('div.dataTables_filter label').css("padding-right", "20%");
        $('div.dataTables_filter label').css("text-align", "center");
    });
    function printDiv(divName) {
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    }
    $("#checkAllapprove").click(function () {
        $('input[id="approvelist"]').not(this).prop('checked', this.checked);
        $('input[id="rejectlist"]').removeAttr('checked');
        $("#checkAllrej").removeAttr('checked');
//        $('input:checkbox').find('#approvelist').prop('checked', this.checked);
    });
    $("#checkAllrej").click(function () {
        $('input[id="rejectlist"]').not(this).prop('checked', this.checked);
        $('input[id="approvelist"]').removeAttr('checked');
        $("#checkAllapprove").removeAttr('checked');
//        $('input:checkbox').find('#rejectlist').prop('checked', this.checked);
    });
    $("#approvelist").click(function () {
        $('input[id="rejectlist"]').removeAttr('checked');
//        $('#rejectlist input[type="checkbox"]').attr('checked', false);
        $("#checkAllrej").removeAttr('checked');
//        $('input:checkbox').find('#rejectlist').prop('checked', this.checked);
    });
    $("#rejectlist").click(function () {
        $('input[id="approvelist"]').removeAttr('checked');
//        $('#approvelist input[type="checkbox"]').attr('checked', false);
        $("#checkAllapprove").removeAttr('checked');
//        $('input:checkbox').find('#rejectlist').prop('checked', this.checked);
    });
    $("#rejlist").click(function () {
        $("#aprovlist").val('');
    });
    $("#aprovlist").click(function () {
        $("#rejlist").val('');
    });
</script>