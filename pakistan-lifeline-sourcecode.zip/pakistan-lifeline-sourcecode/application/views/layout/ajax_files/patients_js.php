<script>
    $(function () {
        
        
        
//        $('#second_skip').prop('disabled', true);
        var max = 11;
        $('#contact_number').keypress(function (e) {
            if (e.which < 0x20) {
                // e.which < 0x20, then it's not a printable character
                // e.which === 0 - Not a character
                return;     // Do nothing
            }
            if (this.value.length == max) {
                e.preventDefault();
            } else if (this.value.length > max) {
                // Maximum exceeded
                this.value = this.value.substring(0, max);
            }
        });
//          $('#checkidmr').on('change', function() {
//                $('#checkidmr').not(this).prop('checked', false);  
//            });
        $("#update_patient_reg").click(function(e){
//           $('#checkidmr').siblings('input:checkbox').prop('checked', false);
//            if($("#age").val() == '')
//            {
//                alert("Please go back and enter age");
//                return false;
//            }
//            if($("#email").val() == '')
//            {
//                alert("Please go back and enter email");
//                return false;
//            }
            var val = [];
//            var userinput = $("#email").val();
            var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
            if (!testEmail.test($("#email").val()) && $("#email").val() != '') 
            {
                alert('Please go back and enter valid email');
                return false;
            }
            
            $(':checkbox:checked').each(function(i){
              val[i] = $(this).val();
            });
            if(val.length <= 1)
            {
              if(val != '')
                {
//                    alert(val); 
                    $("#update_patient_id").val(val);
                    $("#patient_info").submit();
                }
                else{
                    alert('Please select any checkbox');
                }
            }
            else{
                alert('Please Select only one checkbox');
            }
        });
        $("#second_skip").click(function(e){
            $('#email').rules('remove');
//        $('#age').prop('required',false);
//        $('#email').prop('required',false);
        var val = [];
        $(':checkbox:checked').each(function(i){
//            $(this).siblings('input:checkbox').prop('checked', false);
          val[i] = $(this).val();
        });
        if(val.length <= 1)
        {
          if(val != '')
          {
//              alert(val); 
              $("#patient_id_old").val(val);
              $("#patient_info").submit();
          }
          else{
              alert('Please select any checkbox');
          }
        }
        else{
            alert('Please Select only one checkbox');
        }
//            alert(document.getElementById('checkidmr').value);
//                if(document.getElementById('checkidmr').checked)
//                {
////                     var arr = [];
////
////                    $('input[type="checkbox"]:checked').each(function () {
////                      arr.push($(this).val());
//                    });
//
//                    alert("saad"+$('#checkidmr').val());
//                }
//                else{
//                    alert("saadi");
//                }
//               $("#patient_info").submit();
//            if($('#checkidmr').is(":checked")){
//                alert("Checkbox is checked.");
//            }
//            else {
//                alert("Checkbox is unchecked.");
//            }
        });
        $("#second_submit1").click(function(e){
//            if($("#age").val() == '')
//            {
//                alert("Please go back and enter age");
//                return false;
//            }
//            if($("#email").val() == '')
//            {
//                alert("Please go back and enter email");
//                return false;
//            }
            $("#patient_ids").val("");
            var testEmail = /^[A-Z0-9._%+-]+@([A-Z0-9-]+\.)+[A-Z]{2,4}$/i;
            if (!testEmail.test($("#email").val()) && $("#email").val() != '') 
            {
                alert('Please go back and enter valid email');
                return false;
            }
               $("#patient_info").submit();
        });
        $("#second_submit").click(function(e){
//            alert($("#cnic_number").val().length);
        if(($('#cnic_number').val().length == '13' || $('#cnic_number').val() == '') && $('#age').val() != '' && $('#province').val() != '' && $('#district').val() != '' && $('#tehsil').val() != '' && $('#uc').val() != '')
         {
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('patients/get_info'); ?>",
                data: {phone: $("#contact_number").val(),name: $("#full_name").val()},
                dataType: 'html',
                success: function (html) {
                    if(html != '') {
                        $("#same_record").html(html);
                        $("#modal").click();
//                        return true;
                    }                    
                    else
                    {
                        $("#patient_info").submit();
                    }
                }
            });
          } 
          if($('#full_name').val() == '')
            {
                $("#patient_info").submit();
            }
          if($('#full_name').val() != '' && $('#contact_number').val() == '' || $('#contact_number').val().length != '11')
            {
                $("#patient_info").submit();
            }
          if($('#full_name').val() != '' && $('#cnic_number').val().length != '13' && $('#contact_number').val().length == '11' && $('#cnic_number').val() != '')
            {
                $("#cnic_number").focus();
            }
          if($('#full_name').val() != '' && $('#contact_number').val() != '' && $('#age').val() == '' && $('#contact_number').val().length == '11')
            {
                $("#age").focus();
            }
           if($('#full_name').val() != '' && $('#contact_number').val() != '' && $('#age').val() != '' && $('#province').val() == '')
           {
//               $("#province").focus();
                $('#province').select2('open');
           }
           if($('#full_name').val() != '' && $('#contact_number').val() != '' && $('#age').val() != '' && $('#province').val() != '' && $('#district').val() == '')
           {
               $("#district").select2('open');
           }
           if($('#full_name').val() != '' && $('#contact_number').val() != '' && $('#age').val() != '' && $('#province').val() != '' && $('#district').val() != '' && $('#tehsil').val() == '')
           {
               $("#tehsil").select2('open');
           }
           if($('#full_name').val() != '' && $('#contact_number').val() != '' && $('#age').val() != '' && $('#province').val() != '' && $('#district').val() != '' && $('#tehsil').val() != '' && $('#uc').val() == '')
           {
               $("#uc").select2('open');
           }
      });
        var max_cnic = 13;
        $('#cnic_number').keypress(function (e) {
            if (e.which < 0x20) {
                // e.which < 0x20, then it's not a printable character
                // e.which === 0 - Not a character
                return;     // Do nothing
            }
            if (this.value.length == max_cnic) {
                e.preventDefault();
            } else if (this.value.length > max_cnic) {
                // Maximum exceeded
                this.value = this.value.substring(0, max_cnic);
            }
        });
        $("#patient_info").validate({
            rules: {
                full_name: {
                    required:true,
                    lettersonly: true
                },
                age: {
                    required:true,
                    min: 1,
                    max: 120
                },
                contact_number: {
                    required:true,
                    number: true,
                    minlength: 11,
                    maxlength: 11
                },
                cnic_number: {
                    number: true,
                    minlength: 13,
                    maxlength: 13

                },
                email: {
                    emailfull: true
                }
//                province : {
//                    province: "required needsSelection"
//                }
            },
            ignore: [],
//            ignore: ':hidden:not("#province")', // Tells the validator to check the hidden select
//            ignore : ".ignore, :hidden",
//            errorClass: 'invalid'
        });
        jQuery.validator.addMethod("emailfull", function(value, element) {
            return this.optional(element) || /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i.test(value);
           }, "Please enter valid email address!");
        $("#patient_readings").validate({
            rules: {
                temperature: {
                    min: 90,
                    max: 105
                },
                bp_systolic: {
                    min: 1,
                    max: 200
                },
                bp_diastolic: {
                    min: 1,
                    max: 200
                },
                heart_pulse: {
                    min: 40,
                    max: 220
                }
            }
        });
        $.validator.addMethod("needsSelection", function (value, element) {
            return $(element).multiselect("getChecked").length > 0;
        });
        jQuery.validator.addMethod("lettersonly", function (value, element) {
            return this.optional(element) || /^[a-zA-Z ]+$/i.test(value);
        }, "Alphabets only please");

        $.validator.messages.needsSelection = 'Please select a disease.';

        $("#patient_diagnosis").validate({
            rules: {
                disease: "required needsSelection"
            },
            ignore: ':hidden:not("#disease")', // Tells the validator to check the hidden select
            errorClass: 'invalid'
        });
//        $("#medicine_prescription").validate({
//            rules: {
//                medicine: "required needsSelection"
//            },
//            ignore: ':hidden:not("#medicine")', // Tells the validator to check the hidden select
//            errorClass: 'invalid'
//        });
        get_medicines();
        $(document).on("click", "#delete_btn", function () {
            var id = $(this).data("id");
            var visit_id = $(this).data("visit-id");
//            alert(visit_id);
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('patients/delete_prescribed_medicines'); ?>",
                data: {id: id},
                dataType: 'html',
                success: function (data) {
                    $("#days").val('');
                    $('#table_medicine').html('');
                    $("#medicine").select2();
                    get_medicines();
                }
            });
        });
        $("#medicine").change(function () {
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('patients/get_medicine_strength'); ?>",
                data: {medicine_id: $(this).val()},
                dataType: 'html',
                success: function (data) {
                    $("#strength").html(data);
                    $('#strength').trigger('change');
                }
            });
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('patients/get_medicine_dose'); ?>",
                data: {medicine_id: $(this).val()},
                dataType: 'html',
                success: function (data) {
                    $("#dose_form").html(data);
                    $('#dose_form').trigger('change');
                }
            });
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('patients/contradictory_products'); ?>",
                data: {medicine_id: $("#medicine").val(), contrasting_medicine: $("#medicine_string").val()},
                dataType: 'json',
                success: function (data) {
//                    alert(data.message_array);
                    if(data.message_array == 'empty')
                    {
                        $('#contradict_msg').val('');
//                        $('#toaster_info').html('');
                        toastr.clear();
                    }
                    else
                    {
                        $.each(data.message_array, function (index, element) {
    //                        alert(element.message);
                            toastr.info(element.message, element.contradictory_product_name, {timeOut: 0,"extendedTimeOut": "0",tapToDismiss: false,"positionClass": "toast-bottom-left"});
//                            $('#toaster_info').html('<bold>'+element.contradictory_product_name+'<bold> : <br>'+element.message);
//                            $('#toaster_info').css({ 'color': '#2F96B4', 'font-size': '100%' });
                            $('#contradict_msg').val('<bold>'+element.contradictory_product_name+'<bold> : <br>'+element.message);
                                                       
                        });
                        
                    }
                }
            });

        });
        $("#final_submit").click(function () {
            var form = $("#medicine_prescription").serialize();
            if ($("#days").val() != '' && ($("#medicine").val() != '') && ($("#strength").val() != '') && ($("#dose_form").val() != '')) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('patients/add_medicines'); ?>",
                    data: form,
                    dataType: 'json',
                    success: function (data) {
                        $('#table_medicine').html(data.body);
                        $("#medicine").select2();

                        if (data.body) {
                            $(".disable-click").css("pointer-events", 'auto');
                        } else {
                            $(".disable-click").css("pointer-events", 'none');
                        }
                        $("#medicine_string").val(data.medicine_string);
                    },
                    error: function (data)
                    {
                        $(".disable-click").css("pointer-events", 'none');
                    }
                });
                var medicine = $("#medicine").val();
                var medicine_string = $("#medicine_string").val();
                $("#medicine_string").val(medicine_string + ',' + medicine);
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('patients/remove_already_selected'); ?>",
                    data: {medicine_id: $("#medicine_string").val()},
                    dataType: 'json',
                    success: function (data) {
                        var html = "<option value=''></option>";
                        for (var key in data.medicine_array) {
                            html += "<option value=" + key + ">" + data.medicine_array[key] + "</option>"
                        }

                        $('#medicine').html(html);
                        $("#days").val("");
                        $('#medicine').trigger('change'); 

                    }
                });
            }
        });
        $("#province").change(function(){
            var value = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/combo"); ?>',
                data: {
                    id: value,
                    lvl: 4
                },
                dataType: 'html',
                success: function (data) {
                    $("#district").select2("val", "");
                    $("#tehsil").select2("val", "");
                    $("#uc").select2("val", "");
                    $('#district').html(data);
                }
            });
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/cities"); ?>',
                data: {
                    province_id: value
                },
                dataType: 'html',
                success: function (data) {
                    $('#city').html(data);
                }
            });
        });
        $("#district").change(function(){
            var value = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/combo"); ?>',
                data: {
                    id: value,
                    lvl: 5
                },
                dataType: 'html',
                success: function (data) {
                    $("#tehsil").select2("val", "");
                    $("#uc").select2("val", "");
                    $('#tehsil').html(data);
                }
            });
        });

        $("#tehsil").change(function(){
            var value = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/combo"); ?>',
                data: {
                    id: value,
                    lvl: 6
                },
                dataType: 'html',
                success: function (data) {
                    $("#uc").select2("val", "");
                    $('#uc').html(data);
                }
            });
        });
//        $('#search_table').DataTable({
//            dom: 'Bfrtip',
//            buttons: [
//                'copy', 'csv', 'excel', 'pdf', 'print'
//            ]
//        });
        $('#search_table').DataTable({
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'copy',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                },
                {
                    extend: 'csv',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                },
                {
                    extend: 'excel',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                },
                {
                    extend: 'pdf',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                },
                {
                    extend: 'print',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                }
            ]
        });
        $('div.dataTables_filter input').addClass('col-md-4 form-control');
        $('div.dataTables_filter input').css("width", "100%");
        $('div.dataTables_filter label').css("padding-right", "20%");
        $('div.dataTables_filter label').css("text-align", "center");
    });
     function calculate_age(dob, method) {
            if (method == 'age2dob') {
                var birthDate = moment().subtract(dob, 'years');
                $("#day").val(birthDate.format("D"));
                $("#month").val(birthDate.format("M"));
                $("#year").val(birthDate.format("YYYY"));
            } else {
                var dob = $("#year").val() + '-' + $("#month").val() + '-' + $("#day").val();
                var a = moment();
                var b = moment(dob, "YYYY-MM-DD");
                var age_dt = a.diff(b, 'years');

                $("#age").val(age_dt);
            }
        }
    function printDiv(divName) {
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        var printButton = document.getElementById("printPageButton");
        var printButton1 = document.getElementById("gotoparentpage");
        printButton.style.visibility = 'hidden';
        printButton1.style.visibility = 'hidden';
        var curURL = window.location.href;
        history.replaceState(history.state, '', '/');
//        window.print();
        window.print();
        history.replaceState(history.state, '', curURL);
        document.body.innerHTML = originalContents;
        printButton.style.visibility = 'visible';
        printButton1.style.visibility = 'visible';
    }
    function get_medicines() {
        var form = $("#medicine_prescription").serialize();
        $.ajax({
            type: "POST",
            url: "<?php echo base_url('patients/add_medicines'); ?>",
            data: form,
            dataType: 'json',
            success: function (data) {
                $('#table_medicine').html(data.body);
                if (data.body) {
                    $(".disable-click").css("pointer-events", 'auto');
                }
                $("#medicine_string").val(data.medicine_string);

                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('patients/contradictory_products'); ?>",
                    data: {medicine_id: $("#medicine_string").val()},
                    dataType: 'json',
                    success: function (data) {
                        var html = "<option value=''></option>";
                        for (var key in data.medicine_array) {
                            html += "<option value=" + key + ">" + data.medicine_array[key] + "</option>"
                        }
                        $('#medicine').html(html);
                        $("#days").val("");
                        $('#medicine').trigger('change');

                    }
                });
            },
            error: function (data) {
                $(".disable-click").css("pointer-events", 'none');
            }
        });
    }
</script>
