<script>
    $(function () {
        var max = 11;
        $('#contact_number').keypress(function (e) {
            if (e.which < 0x20) {
                // e.which < 0x20, then it's not a printable character
                // e.which === 0 - Not a character
                return;     // Do nothing
            }
            if (this.value.length == max) {
                e.preventDefault();
            } else if (this.value.length > max) {
                // Maximum exceeded
                this.value = this.value.substring(0, max);
            }
        });
        var max_cnic=13;
        $('#cnic_number').keypress(function (e) {
            if (e.which < 0x20) {
                // e.which < 0x20, then it's not a printable character
                // e.which === 0 - Not a character
                return;     // Do nothing
            }
            if (this.value.length == max_cnic) {
                e.preventDefault();
            } else if (this.value.length > max_cnic) {
                // Maximum exceeded
                this.value = this.value.substring(0, max_cnic);
            }
        });
        $("#patient_info").validate({
            rules: {
                full_name: {
                    lettersonly: true
                },
                age: {
                    min: 1,
                    max: 120
                },
                contact_number: {
                    number: true,
                    minlength: 10,
                    maxlength: 11
                },
                cnic_number: {
                    number: true,
                    minlength: 13,
                    maxlength: 13

                },
                email: {
                    email: true
                }
            }
        });
        $("#patient_readings").validate({
            rules: {
                temperature: {
                    min: 90,
                    max: 105
                },
                bp_systolic: {
                    min: 1,
                    max: 200
                },
                bp_diastolic: {
                    min: 1,
                    max: 200
                },
                heart_pulse: {
                    min: 40,
                    max: 220
                }
            }
        });
        $.validator.addMethod("needsSelection", function (value, element) {
            return $(element).multiselect("getChecked").length > 0;
        });
        jQuery.validator.addMethod("lettersonly", function (value, element) {
            return this.optional(element) || /^[a-zA-Z ]+$/i.test(value);
        }, "Alphabets only please");

        $.validator.messages.needsSelection = 'Please select a disease.';

        $("#patient_diagnosis").validate({
            rules: {
                disease: "required needsSelection"
            },
            ignore: ':hidden:not("#disease")', // Tells the validator to check the hidden select
            errorClass: 'invalid'
        });
        $("#medicine_prescription").validate({
            rules: {
                medicine: "required needsSelection"
            },
            ignore: ':hidden:not("#medicine")', // Tells the validator to check the hidden select
            errorClass: 'invalid'
        });
        get_medicines();
        $(document).on("click", "#delete_btn", function () {
            var id = $(this).data("id");
            var visit_id = $(this).data("visit-id");
//            alert(visit_id);
            $.ajax({
                type: "POST",
                url: "<?php echo base_url('patients/delete_prescribed_medicines'); ?>",
                data: {id: id},
                dataType: 'html',
                success: function (data) {
                    $("#days").val('');
                    $('#table_medicine').html('');
                    $("#medicine").select2();
                    get_medicines();
                }
            });
        });
        $("#final_submit").click(function () {
            var form = $("#medicine_prescription").serialize();
            if ($("#days").val() != '' && ($("#medicine").val() != '')) {
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('patients/add_medicines'); ?>",
                    data: form,
                    dataType: 'json',
                    success: function (data) {
                        $('#table_medicine').html(data.body);
                        $("#medicine").select2();

                        if (data.body) {
                            $(".disable-click").css("pointer-events", 'auto');
                        } else {
                            $(".disable-click").css("pointer-events", 'none');
                        }
                        $("#medicine_string").val(data.medicine_string);
                    },
                    error: function (data)
                    {
                        $(".disable-click").css("pointer-events", 'none');
                    }
                });
                var medicine = $("#medicine").val();
                var medicine_string = $("#medicine_string").val();
                $("#medicine_string").val(medicine_string + ',' + medicine);
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('patients/contradictory_products'); ?>",
                    data: {medicine_id: $("#medicine_string").val()},
                    dataType: 'html',
                    success: function (data) {
                        $('#medicine').html(data);
                        $("#days").val("");
                        $('#medicine').trigger('change');
                    }
                });
            }
        });
//        $('#search_table').DataTable({
//            dom: 'Bfrtip',
//            buttons: [
//                'copy', 'csv', 'excel', 'pdf', 'print'
//            ]
//        });
        $('#search_table').DataTable({
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'copy',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                },
                {
                    extend: 'csv',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                },
                {
                    extend: 'excel',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                },
                {
                    extend: 'pdf',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                },
                {
                    extend: 'print',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                }
            ]
        });
        $('div.dataTables_filter input').addClass('col-md-4 form-control');
        $('div.dataTables_filter input').css("width", "100%");
        $('div.dataTables_filter label').css("padding-right", "20%");
        $('div.dataTables_filter label').css("text-align", "center");
    });
    function printDiv(divName) {
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    }
    function get_medicines() {
        var form = $("#medicine_prescription").serialize();
        $.ajax({
            type: "POST",
            url: "<?php echo base_url('patients/add_medicines'); ?>",
            data: form,
            dataType: 'json',
            success: function (data) {
                $('#table_medicine').html(data.body);
                if (data.body) {
                    $(".disable-click").css("pointer-events", 'auto');
                }
                $("#medicine_string").val(data.medicine_string);

                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url('patients/contradictory_products'); ?>",
                    data: {medicine_id: $("#medicine_string").val()},
                    dataType: 'html',
                    success: function (data) {
//                        $(".select2-chosen").html("");
                        $('#medicine').html(data);
                        $('#medicine').trigger('change');
                    }
                });
            },
            error: function (data) {
                $(".disable-click").css("pointer-events", 'none');
            }
        });
    }
</script>