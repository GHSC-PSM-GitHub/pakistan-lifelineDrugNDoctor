<script>
    $(function () {

        $(".keyup").keyup(function () {

            var id = $(this).data("id");
            var amount = (($("#sale_qty-" + id).val()) * ($("#price-" + id).val()));
//            alert(amount);
            $("#amount-" + id).val(amount);
            var sum = 0;
            $(".amount-class").each(function () {

                if ($(this).val() != '' || $(this).val() != 0)
                {
                    sum += parseInt($(this).val());
                    $("#total").val(sum);
                }
            });

        });
        $("#paid").on("keyup change", function () {
            $("#balance").val(($("#paid").val()) - ($("#total").val()));
        });
        $('#search_table_without_btn').DataTable();
          $('#search_table').DataTable({
            dom: 'Bfrtip',
            buttons: [
                {
                    extend: 'copy',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                },
                {
                    extend: 'csv',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                },
                {
                    extend: 'excel',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                },
                {
                    extend: 'pdf',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                },
                {
                    extend: 'print',
                    exportOptions: {
                        columns: ':not(.notexport)'
                    }
                }
            ]
        });
        $('div.dataTables_filter input').addClass('col-md-4 form-control');
        $('div.dataTables_filter input').css("width", "100%");
        $('div.dataTables_filter label').css("padding-right", "20%");
        $('div.dataTables_filter label').css("text-align", "center");
    });
    function printDiv(divName) {
        var printContents = document.getElementById(divName).innerHTML;
        var originalContents = document.body.innerHTML;
        document.body.innerHTML = printContents;
        window.print();
        document.body.innerHTML = originalContents;
    }
</script>