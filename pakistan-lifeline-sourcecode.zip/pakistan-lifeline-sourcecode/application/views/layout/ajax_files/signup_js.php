<script>
    $(function () {
        
      $("#second_submit").click(function(e){
//            alert($("#cnic_number").val().length);
          if($('#full_name').val() == '')
            {
                $('#full_name').focus();
//                $("#signup_deets").submit();
            }
          if($('#full_name').val() != '' && $('#phone').val() == '' || $('#phone').val().length != '11')
            {
                $("#phone").focus();
            }
            if($('#full_name').val() != '' &&  $('#phone').val().length == '11' && ($('#cnic_number').val().length != '13' || $('#cnic_number').val() == ''))
            {
                $("#cnic_number").focus();
            }
            if($('#full_name').val() != '' && $('#phone').val() != '' && $('#cnic_number').val().length == '13' && $('#phone').val().length == '11' && $('#clinic_name').val() == '')
            {
                $("#clinic_name").focus();
            }
            if($('#full_name').val() != '' && $('#phone').val() != '' && $('#phone').val().length == '11' && $('#cnic_number').val().length == '13' && $('#clinic_name').val() != '' && $('#email').val() == '' )
            {
                $("#email").focus();
            }
           if($('#full_name').val() != '' && $('#phone').val() != '' && $('#phone').val().length == '11' && $('#cnic_number').val().length == '13' && $('#clinic_name').val() != '' && $('#email').val() != '' && $('#province').val() == '')
           {
//               $("#province").focus();
                $('#province').select2('open');
           }
           if($('#full_name').val() != '' && $('#phone').val() != '' && $('#province').val() != '' && $('#cnic_number').val().length == '13' && $('#phone').val().length == '11' && $('#clinic_name').val() != '' && $('#email').val() != ''  && $('#district').val() == '')
           {
               $("#district").select2('open');
           }
           if($('#full_name').val() != '' && $('#phone').val() != '' && $('#province').val() != '' && $('#cnic_number').val().length == '13' && $('#district').val() != '' && $('#phone').val().length == '11' && $('#clinic_name').val() != '' && $('#email').val() != ''  && $('#tehsil').val() == '')
           {
               $("#tehsil").select2('open');
           }
           if($('#full_name').val() != '' && $('#phone').val() != '' && $('#province').val() != '' && $('#cnic_number').val().length == '13' && $('#district').val() != '' && $('#tehsil').val() != '' && $('#phone').val().length == '11' && $('#clinic_name').val() != '' && $('#email').val() != ''  && $('#uc').val() == '')
           {
               $("#uc").select2('open');
           }
      });
//        $("#email").keyup(function(){
//            var email = $("#email").val();
//            var emailReg = /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/;
//            return emailReg.test(email);
//        });
        $("#signup_deets").validate({
            rules: {  
                pmdc_no: {
                    required: true,
                    remote: {
                        url: "<?php echo base_url('welcome/pmdc_no_check') ?>",
                        type: "post"
                        
                    }
                },
                phone: {
                    number: true
                }, 
                cnic_number: {
                    number: true
                },
                email: {
                    required:true,
                    emailfull:true
                }, 
                clinic_name: {
                    required: true,
                    minlength : 5
                }
            },
            messages: {
                pmdc_no: { 
                    required:"Please enter userid/pmdc number",
                    remote: jQuery.validator.format("User Already exists against the entered PMDC Number. Please login using your PMDC Number and Password.")
                }
            },
            ignore: ".ignore"
        });
        jQuery.validator.addMethod("emailfull", function(value, element) {
            return this.optional(element) || /^([a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+(\.[a-z\d!#$%&'*+\-\/=?^_`{|}~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]+)*|"((([ \t]*\r\n)?[ \t]+)?([\x01-\x08\x0b\x0c\x0e-\x1f\x7f\x21\x23-\x5b\x5d-\x7e\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|\\[\x01-\x09\x0b\x0c\x0d-\x7f\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]))*(([ \t]*\r\n)?[ \t]+)?")@(([a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\d\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.)+([a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]|[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF][a-z\d\-._~\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF]*[a-z\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])\.?$/i.test(value);
           }, "Please enter valid email address!");
           
           
           $("#province").change(function(){
            var value = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/combo"); ?>',
                data: {
                    id: value,
                    lvl: 4
                },
                dataType: 'html',
                success: function (data) {
//                    $('#district option[value='']').prop('selected', 'selected').change();
//                    $('#district option[value=""]').attr("selected", "selected");
//                    $('#district option:eq(0)').prop('selected', true);
//                    alert($('#district option:eq(0)'));
//                    $('#district option:eq(0)').attr('selected', true);
//                    $('#district option:contains("Select")');
//                    $('#district').val('select');
                    $("#district").select2("val", "");
                    $("#tehsil").select2("val", "");
                    $("#uc").select2("val", "");
                    $('#district').html(data);
                }
            });
//            $.ajax({
//                type: "POST",
//                url: '<?php echo base_url("ajax/cities"); ?>',
//                data: {
//                    province_id: value
//                },
//                dataType: 'html',
//                success: function (data) {
//                    $('#city').html(data);
//                }
//            });
        });
        $("#district").change(function(){
            var value = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/combo"); ?>',
                data: {
                    id: value,
                    lvl: 5
                },
                dataType: 'html',
                success: function (data) {
                    $("#tehsil").select2("val", "");
                    $("#uc").select2("val", "");
                    $('#tehsil').html(data);
                }
            });
        });

        $("#tehsil").change(function(){
            var value = $(this).val();
            $.ajax({
                type: "POST",
                url: '<?php echo base_url("ajax/combo"); ?>',
                data: {
                    id: value,
                    lvl: 6
                },
                dataType: 'html',
                success: function (data) {
                    $("#uc").select2("val", "");
                    $('#uc').html(data);
                }
            });
        });
        
        $('input[name=pmdc_no]').on('keyup',function() {
          var v = $(this).val();
          if (!v.match(/^-?[a-zA-Z-0-9]*$/))
            $(this).val(v.replace(/(?!^-)[^a-zA-Z-0-9]/g,''));
        });
        
        
    });
</script>