<?php     
if(isset($reject) && !empty($reject))
{
    for($i=0;$i<count($number);++$i){
         $to = $number[$i]->email;
         $from = "feedback@lmis.gov.pk";
         $subject = "Doctors' Hub Registration Info";
         
         $message = "Your request to “Register” on Doctor’s Hub Application has been rejected due to the invalid credentials
         in verification as per PMC record. For any queries, write us at “support@lmis.gov.pk”.";
         
         $header = "From:".$from."\r\n";
//         $header .= "Cc:afgh@somedomain.com \r\n";
         $header .= "MIME-Version: 1.0\r\n";
         $header .= "Content-type: text/html\r\n";
         
         mail ($to,$subject,$message,$header);
         
    }
}
if(isset($userinfo) && !empty($userinfo))
{
//    echo $userinfo[0]->phone;
//    exit;
    for($i=0;$i<count($nursepass);++$i){
        
        $message  = '<html><body>';
        $message .= "<b>Dear ".$userinfo[$i]->full_name."</b><br><br>\r\n";
//        $message .= "Your request for registration has been Approved.Two Users are created First Username is: '" . $userinfo[$i]->pmdc_no .'_nurse' . "' & Password is:'".$nursepass[$i]."' AND Second Username is: '" . $userinfo[$i]->pmdc_no . '_fdesk' . "' & Password is:'".$fdeskpass[$i]."'";
        $message .= "Your registration has been approved by PMC. Please login to Doctor’s Hub application using your Login and Password. Following users have been created for your team members:<br><br>\r\n";
        $message .= "<table style='font-family: arial, sans-serif;border-collapse: collapse;width: 50%;'>";
        $message .= "<thead>";
        $message .= "<tr>";
        $message .= "<th style='border: 1px solid #dddddd;text-align: left;padding: 8px;'>Employee</th>";
        $message .= "<th style='border: 1px solid #dddddd;text-align: left;padding: 8px;'>Login</th>";
        $message .= "<th style='border: 1px solid #dddddd;text-align: left;padding: 8px;'>Password</th>";
        $message .= "</tr>";
        $message .= "</thead>";
        $message .= "<tbody>";
        $message .= "<tr><td style='border: 1px solid #dddddd;text-align: left;padding: 8px;'>Nurse</td>";
        $message .= "<td style='border: 1px solid #dddddd;text-align: left;padding: 8px;'>" . $userinfo[$i]->pmdc_no .'_nurse' . "</td>";
        $message .= "<td style='border: 1px solid #dddddd;text-align: left;padding: 8px;'>".$nursepass[$i]."</td></tr>";
        $message .= "<tr><td style='border: 1px solid #dddddd;text-align: left;padding: 8px;'>Front Desk</td>";
        $message .= "<td style='border: 1px solid #dddddd;text-align: left;padding: 8px;'>" . $userinfo[$i]->pmdc_no . '_fdesk' . "</td>";
        $message .= "<td style='border: 1px solid #dddddd;text-align: left;padding: 8px;'>".$fdeskpass[$i]."</td></tr>";
        $message .= "</tbody>";
        $message .= "</table><br>\r\n";
        $message .= "For any further information , please contact support@nih.gov.pk";
        $message .= '</body></html>';
//         $message = "Your request for registration has been Approved.Two Users are created First Username is: '" . $userinfo[$i]->pmdc_no .'_nurse' . "' & Password is:'".$nursepass[$i]."' AND Second Username is: '" . $userinfo[$i]->pmdc_no . '_fdesk' . "' & Password is:'".$fdeskpass[$i]."'";
         $to = $userinfo[$i]->email;
         $from = "feedback@lmis.gov.pk";
         $subject = "Subject: Doctor’s Hub - Registration Approval";
         
//         $message = "Your request for registration has been Rejected";
         
         $header = "From:".$from."\r\n";
//         $header .= "Cc:afgh@somedomain.com \r\n";
         $header .= "MIME-Version: 1.0\r\n";
         $header .= "Content-type: text/html\r\n";
         
         mail ($to,$subject,$message,$header);
    }
}
if(empty($reject) && empty($userinfo)){
     $to = $email;
     $from = "feedback@lmis.gov.pk";
     $subject = "Doctors' Hub Registration Info";
     
     $message = "Your request for registration has been submitted successfully, please wait till PMDC verification. You will be notified through provided *Mobile Number* & *Email* upon verification.";

     $header = "From:".$from."\r\n";
//         $header .= "Cc:afgh@somedomain.com \r\n";
     $header .= "MIME-Version: 1.0\r\n";
     $header .= "Content-type: text/html\r\n";

     mail ($to,$subject,$message,$header);
}  
       
?>
       