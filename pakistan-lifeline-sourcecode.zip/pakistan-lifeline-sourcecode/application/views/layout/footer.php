<!-- Footer -->
<footer class="footer">
    For any comments and suggestions please write to <a href="mailto: "> Support Email</a>
</footer>
</div>
<!-- /#page-wrapper -->
</div>
<!-- /#wrapper -->
<!-- jQuery -->
<script src="<?php echo base_url('assets/plugins/components/jquery/dist/jquery.min.js') ?>"></script>
<!-- Bootstrap Core JavaScript -->
<script src="<?php echo base_url('assets/theme_files/bootstrap/dist/js/bootstrap.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/components/jquery_validation/jquery.validate.js') ?>"></script>
<script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.2/dist/additional-methods.min.js"></script>

<!-- Sidebar menu plugin JavaScript -->
<script src="<?php echo base_url('assets/theme_files/js/sidebarmenu.js') ?>"></script>
<!--Slimscroll JavaScript For custom scroll-->
<script src="<?php echo base_url('assets/theme_files/js/jquery.slimscroll.js') ?>"></script>
<!--Wave Effects -->
<script src="<?php echo base_url('assets/theme_files/js/waves.js') ?>"></script>
<!-- Custom Theme JavaScript -->
<script src="<?php echo base_url('assets/theme_files/js/custom.js') ?>"></script>

<script src="<?php echo base_url('assets/plugins/components/switchery/dist/switchery.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/components/custom-select/custom-select.min.js') ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/plugins/components/bootstrap-select/bootstrap-select.min.js') ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/plugins/components/bootstrap-tagsinput/dist/bootstrap-tagsinput.min.js') ?>"></script>
<script src="<?php echo base_url('assets/plugins/components/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.js') ?>" type="text/javascript"></script>
<script src="<?php echo base_url('assets/plugins/components/datatables/jquery.dataTables.min.js')?>"></script>
<script src="<?php echo base_url('assets/plugins/components/bootstrap-toastr/toastr.min.js')?>"></script>
<script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js"></script>
<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js"></script>
<script src="https://cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
<script>
    jQuery(document).ready(function () {
        // For select 2
        $(".select2").select2();
    });
</script>
</body>

</html>
