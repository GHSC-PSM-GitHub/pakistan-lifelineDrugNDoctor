<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" type="image/png" sizes="16x16" href="../plugins/images/favicon.png">
        <title>Doctor's Hub</title>
        <!-- ===== Bootstrap CSS ===== -->
        <link href="<?php echo base_url('assets/theme_files/bootstrap/dist/css/bootstrap.min.css') ?>" rel="stylesheet">
        <!-- ===== Plugin CSS ===== -->
        <link href="https://cdn.datatables.net/buttons/1.2.2/css/buttons.dataTables.min.css" rel="stylesheet" type="text/css" />

        <!-- ===== Animation CSS ===== -->
        <link href="<?php echo base_url('assets/theme_files/css/animate.css') ?>" rel="stylesheet">
        <!-- ===== Custom CSS ===== -->
        <link href="<?php echo base_url('assets/theme_files/css/style.css') ?>" rel="stylesheet">
        <!-- ===== Color CSS ===== -->
        <link href="<?php echo base_url('assets/theme_files/css/colors/default.css') ?>" id="theme" rel="stylesheet"> 
        <link href="<?php echo base_url('assets/plugins/components/bootstrap-datepicker/bootstrap-datepicker.min.css') ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url('assets/plugins/components/custom-select/custom-select.css') ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url('assets/plugins/components/switchery/dist/switchery.min.css') ?>" rel="stylesheet" />
        <link href="<?php echo base_url('assets/plugins/components/bootstrap-select/bootstrap-select.min.css') ?>" rel="stylesheet" />
        <link href="<?php echo base_url('assets/plugins/components/bootstrap-tagsinput/dist/bootstrap-tagsinput.css') ?>" rel="stylesheet" />
        <link href="<?php echo base_url('assets/plugins/components/bootstrap-touchspin/dist/jquery.bootstrap-touchspin.min.css') ?>" rel="stylesheet" />
        <link href="<?php echo base_url('assets/plugins/components/datatables/jquery.dataTables.min.css') ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo base_url('assets/plugins/components/bootstrap-toastr/toastr.min.css') ?>" rel="stylesheet" type="text/css" />

        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>

    <body class="mini-sidebar">
        <!-- Preloader -->
        <div class="preloader">
            <div class="cssload-speeding-wheel"></div>
        </div>
        <div id="wrapper">
            <!-- ===== Top-Navigation ===== -->
            <nav class="navbar navbar-default navbar-static-top m-b-0">
                <div class="navbar-header">
                    <a class="navbar-toggle font-20 hidden-sm hidden-md hidden-lg " href="javascript:void(0)" data-toggle="collapse" data-target=".navbar-collapse">
                        <i class="fa fa-bars"></i>
                    </a>
                    <div class="top-left-part">
                        <a class="logo" href="<?php if(isset($_SESSION['role']) && $_SESSION['role'] == 'P') { echo base_url("pmdc/pending_approvals_list"); } else {echo base_url("patients/search_patients");}?>">
                            <b>
                                <img src="<?php echo base_url('assets/plugins/images/doctor.jpg') ?>" alt="home" height="65" width="60"/>
                            </b>
                            <span>
                                Doctor's Hub
                            </span>
                        </a>
                    </div>
                    <ul class="nav navbar-top-links navbar-left hidden-xs">
                        <li>
                            <a href="javascript:void(0)" class="sidebartoggler font-20 waves-effect waves-light" ><i class="icon-arrow-left-circle"></i></a>
                        </li>

                    </ul> 
                    <ul class="nav navbar-top-links navbar-right pull-right" style="background-color: white;padding-left:8%;">
                        <li class="dropdown">
                            
                            <img src="<?php echo base_url('assets/plugins/images/govt.jfif') ?>" alt="home" height="65" width="65"/> 
                            <img src="<?php echo base_url('assets/plugins/images/nih.jfif') ?>" alt="home" height="65" width="65"/>
                            <img src="<?php echo base_url('assets/plugins/images/SKM logo.jpg') ?>" alt="home" height="65" width="65"/>

                        </li>
                    </ul>
                </div>
            </nav>
            <?php include "top-menu.php"; ?>
          