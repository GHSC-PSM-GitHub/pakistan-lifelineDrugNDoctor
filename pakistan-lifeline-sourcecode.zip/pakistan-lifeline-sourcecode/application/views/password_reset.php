<?php

if($this->session->flashdata('msg'))    
{   
    $msg = $this->session->flashdata('msg');
?>
<script type="text/javascript">
        alert('<?php echo $msg;?>');
//        alert('<?php // echo $name; ?>');
</script>
<?php
} else {
    
}
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="keywords" content="">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" type="image/png" sizes="16x16" href="..assets/plugins/images/favicon.png">
        <title>Doctors' Hub</title>
        <!-- ===== Bootstrap CSS ===== -->
        <link href="<?php echo base_url('assets/theme_files/bootstrap/dist/css/bootstrap.min.css') ?>" rel="stylesheet">
        <!-- ===== Plugin CSS ===== -->
        <!-- ===== Animation CSS ===== -->
        <!-- ===== Animation CSS ===== -->
        <link href="<?php echo base_url('assets/theme_files/css/animate.css') ?>" rel="stylesheet">
        <!-- ===== Custom CSS ===== -->
        <link href="<?php echo base_url('assets/theme_files/css/style.css') ?>" rel="stylesheet"> 
    </head>

    <body class="mini-sidebar">
        <!-- Preloader -->
        <div class="preloader">
            <div class="cssload-speeding-wheel"></div>
        </div>
        <section id="wrapper" class="login-register" style="background: url(<?php echo base_url('assets/plugins/images/Back-01.jpg') ?>) center center/cover no-repeat!important;">
            <div class="login-box">
                <div class="white-box">
                    <div class="text-center m-t-0 m-b-15">
                        <a href="<?php echo base_url("/"); ?>" class="logo logo-admin"><img src="../assets/plugins/images/logo_1.jfif" alt="" height="120" width="320"></a>
                    </div>
                    <h3 class="text-center box-title m-b-20" style="font-size:18">Reset Password <br/> Doctors' Hub</h3>

                    <form class="form-horizontal form-material" id="" action="<?php echo base_url("welcome/password_reset"); ?>" method="post">
                        <!--<h3 class="box-title m-b-20">Sign In</h3>-->
                        <div class="form-group ">
                            <div class="col-xs-12">
                                <input class="form-control" type="password" required="" placeholder="Old Password" name="old_password">
                            </div>
                        </div>
                        <div class="form-group">
                            <div class="col-xs-12">
                                <input class="form-control" type="password" minlength="5" required="" placeholder="New Password" name="new_password">
                            </div>
                        </div>

                        <div class="form-group text-center m-t-20">
                            <div class="col-xs-12">
                                <button class="btn btn-info btn-lg btn-block text-uppercase waves-effect waves-light" type="submit">Reset</button>
                            </div>
                        </div>
                        <div class="form-group m-b-0">
                        <div class="col-sm-12 text-center">
                            <p>Don't want to change? <a href="<?php if($_SESSION['role'] == 'P') { echo base_url("pmdc/pending_approvals_list"); } else {echo base_url("patients/search_patients");}?>" class="text-primary m-l-5"><b>Click here</b></a></p>
                        </div>
                    </div>

                    </form>

                </div>
            </div>
        </section>
        <!-- jQuery -->
        <script src="<?php echo base_url('assets/plugins/components/jquery/dist/jquery.min.js') ?>"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="<?php echo base_url('assets/theme_files/bootstrap/dist/js/bootstrap.min.js') ?>"></script>
        <!-- Sidebar menu plugin JavaScript -->
        <script src="<?php echo base_url('assets/theme_files/js/sidebarmenu.js') ?>"></script>
        <!--Slimscroll JavaScript For custom scroll-->
        <script src="<?php echo base_url('assets/theme_files/js/jquery.slimscroll.js') ?>"></script>
        <!--Wave Effects -->
        <script src="<?php echo base_url('assets/theme_files/js/waves.js') ?>"></script>
        <!-- Custom Theme JavaScript -->
        <script src="<?php echo base_url('assets/theme_files/js/custom.js') ?>"></script>
        <!--Style Switcher -->
        <script src="<?php echo base_url('assets/plugins/components/styleswitcher/jQuery.style.switcher.js') ?>"></script>
    </body>

</html>
