<?php
if (isset($patient_info)) {
    $row = $patient_info[0];
    $name = $row['full_name'];
    $mr_no = "MR-" . $row['pk_id'];
    $string= $row['age'];
    $str_arr = str_replace("-",",",$string);
    $age = explode (",", $str_arr);
    $gender = $row['gender'];
    $diff = abs(strtotime(date("Y-m-d"))-strtotime($string));
    $years = floor($diff / (365*60*60*24));
    $contact_number = $row['mobile_no'];
    $cnic_number = $row['nic_no'];
}
if (isset($patient_visit_info)) {
    $row_visit = $patient_visit_info[0];
    $temperature = $row_visit['temperature'];
    $bp_upper = $row_visit['bp_upper'];
    $bp_lower = $row_visit['bp_lower'];
    $heart_rate = $row_visit['pulse'];
    $visit_id = $row_visit['pk_id'];
}
if (isset($patient_diagnosis_info)) {
    $row_diagnosis = $patient_diagnosis_info;
    $d_notes = $patient_diagnosis_info[0];
    $diagnosis_notes = $d_notes['notes'];
}
if (isset($patient_test_info)) {
    $row_tests = $patient_test_info;
}
if (isset($patient_medicines_info)) {
    $row_medicines = $patient_medicines_info;
}
?>
<style>
@font-face {
  font-family: 'Libre Barcode 39';
  font-style: normal;
  font-weight: 400;
  src: url(https://fonts.gstatic.com/s/librebarcode39/v14/-nFnOHM08vwC6h8Li1eQnP_AHzI2G_Bx0g.woff2) format('woff2');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
@media print {
  #printPageButton {
    display: none !important;
  }
  #gotoparentpage {
    display: none !important;
  }
  .sidebar {
      display: none !important;
  }
  @page { size: 300mm 212mm; /* landscape */
    /* you can also specify margins here: */
    margin: 5mm;
    margin-right: 5mm; /* for compatibility with both A4 and Letter */ }
  body { margin: .6cm; }
  
}
/*table, th, td {
  border: 1px solid black;
  border-collapse: collapse;
}*/
</style>
<!-- Page Content -->
<div class="page-wrapper" id="print_div">
    <div class="container-fluid">
        <!-- .row -->
        <div class="row">
            <div class="col-md-12">
                <div class="white-box">
                    <div class="row">
                        <div class="col-md-12" style="display:flex;">
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                <br><br><br>
                                <img alt="<?php echo $visit_id; ?>" src="<?php echo base_url('barcode.php?codetype=Code25&size=40&text='.sprintf("%010d", $visit_id)); ?>" />
                             <br><br>
                             <h5 style="font-size: 12px;font-family: calibri;color:black;float:left;margin-top:-15px;"><b>Prescription No:</b> <?php echo "<b>PR-" . $visit_id."</b>" ?></h5>
                            </div>
                            <div class="col-xs-6 col-sm-6 col-md-6 col-lg-6">
                                <a class="logo logo-admin"><img src="../assets/plugins/images/logo_1.jfif" alt="" height="90" width="320"></a>
                                <br>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="display:flex;">
                                        <!--<div class="col-md-6">-->
                                            <!--<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">-->
                                                <h5 style="color:black;font-size: 14px;font-family: calibri;"><b>Clinic Name:</h5>
<!--                                            </div>
                                            <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">-->
                                                <h5 style="font-size: 14px;font-family: calibri;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_SESSION['clinic_name']; ?></h5>
                                            <!--</div>-->
                                            <!--</div>-->
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12" style="display:flex;margin-top: -17px;">
                                        <!--<div class="col-md-6">-->
                                            <!--<div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">-->
                                                <h5 style="color:black;font-size: 14px;font-family: calibri;"><b>Clinic Address:</h5>
<!--                                            </div>
                                            <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">-->
                                                <h5 style="font-size: 14px;font-family: calibri;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $_SESSION['address']; ?></h5>
                                            <!--</div>-->
                                            <!--</div>-->
                                    </div>
                                </div>
                                                
                                            
                                    </div>
                                </div>
                            </div>
                    <div class="row">
                        <div class="col-md-12"> 
                            <h5 style="color:black;font-size: 18px;font-family: calibri light;"><b>Patient's Detail </b></h5>
                            <!--<hr>-->
                            <div class="row">
                                <div class="col-md-12" style="display:flex;">
                                   <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                        <label style="color:black;font-size: 13px;font-family: calibri;"><b>MR Number: </b></label>
                                   </div>
                                    <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                        <label style="color:black;font-size: 13px;font-family: calibri;"><?php echo $mr_no; ?></label>
                                    </div>
                                    <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                        <label  style="color:black;font-size: 13px;font-family: calibri;"><b>Name: </b></label>
                                    </div>
                                    <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                        <label style="color:black;font-size: 13px;font-family: calibri;"><?php echo $name; ?></label>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                               <div class="col-md-12" style="display:flex;">
                                    <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                        <label style="color:black;font-size: 13px;font-family: calibri;"><b>Gender: </b></label>
                                    </div>
                                    <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                        <label style="color:black;font-size: 13px;font-family: calibri;"><?php echo $gender; ?></label>
                                    </div>
                                    <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                        <label style="color:black;font-size: 13px;font-family: calibri;"><b>Age: </b></label>
                                    </div>
                                    <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                        <label style="color:black;font-size: 13px;font-family: calibri;"><?php echo $years.' Years'; ?></label>
                                    </div>
                               </div>
                            </div>
                            <div class="row">
                               <div class="col-md-12" style="display:flex;">
                                        <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <label style="color:black;font-size: 13px;font-family: calibri;"><b>Contact Number: </b></label>
                                        </div>
                                        <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <label style="color:black;font-size: 13px;font-family: calibri;"><?php echo $contact_number; ?></label>
                                        </div>
                                        <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <label style="color:black;font-size: 13px;font-family: calibri;"><b>CNIC: </b></label>
                                        </div>
                                        <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                            <label style="color:black;font-size: 13px;font-family: calibri;"><?php echo $cnic_number; ?></label>
                                        </div>
                               </div>
                            </div>
                        </div>

                    </div>
                    <!--<hr/>-->
                    <div class="row">
                        <div class="col-md-12"> 
                            <h5 style="color:black;font-size: 18px;font-family: calibri light;"><b>Patient's Vitals</b></h5>
                            <!--<hr>-->
                            <div class="row">
                              <div class="col-md-12" style="display:flex;">
                                <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                    <label style="color:black;font-size: 13px;font-family: calibri;"><b>Temperature: </b></label>
                                </div>
                                <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                                    <label style="color:black;font-size: 13px;font-family: calibri;"><?php echo $temperature.' (degrees Fahrenheit)'; ?></label>
                                </div>
                              </div>
                            </div>
                            <div class="row">  
                              <div class="col-md-12" style="display:flex;">
                                <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                    <label style="color:black;font-size: 13px;font-family: calibri;"><b>Blood Pressure: </b></label>
                                </div>
                                <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                                    <label style="color:black;font-size: 13px;font-family: calibri;"><?php echo $bp_upper .' / '.$bp_lower.' mmHg'; ?></label>
                                </div>
                              </div>
                             </div> 
                            <div class="row">
                              <div class="col-md-12" style="display:flex;">
                                <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3">
                                    <label style="color:black;font-size: 13px;font-family: calibri;"><b>Heart Rate: </b></label>
                                </div>
                                <div class="col-xs-4 col-sm-4 col-md-4 col-lg-4">
                                    <label  style="color:black;font-size: 13px;font-family: calibri;"><?php echo $heart_rate.' (beats per minute)'; ?></label>
                                </div>
                              </div>
                            </div>
                        </div>
                     </div>
                    <!--<hr/>-->
                    <div class="row">
                        <div class="col-md-12"> 
                            <h5 style="color:black;font-size: 18px;font-family: calibri light;"><b>Clinical Diagnosis</b></h5>
                            <!--<hr>-->
                            <div class="row">
                                <div class="col-md-12" style="display:flex;">
                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <!--<label  style="color:black;font-size: 13px;font-family: calibri;"><b>Diseases Diagnosed: </b></label>-->
                                    <!--<br>-->
                                    <?php
                                    $count = 1;
                                    if(!empty($row_diagnosis))
                                    {
                                        foreach ($row_diagnosis as $key => $value_array) {
                                            ?>
                                            <label style="color:black;font-size: 13px;font-family: calibri;"><?php echo $count . " - " . $value_array['disease_name']; ?></label><br>
                                            <?php
                                            $count++;
                                        }
                                    }
                                    ?>

                                </div>
                                </div>
                            </div>
                            <!--<br>-->
<!--                            <div class="row">
                                <label style="color:black;margin-left: 5%"><b>Notes: </b></label>
                                <label style="margin-left:2%;"><?php // if(isset($diagnosis_notes) && !empty($diagnosis_notes)){ echo $diagnosis_notes;} ?></label><br>
                            </div>-->
                        </div>

                    </div>
                    <!--<hr/>-->
                    <div class="row">
                        <div class="col-md-12"> 
                            <h5 style="color:black;font-size: 18px;font-family: calibri light;"><b>Lab Order</b></h5>
                            <!--<hr>-->
                            <div class="row">
                                <div class="col-md-12" style="display:flex;">

                                <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                    <?php
                                    $count = 1;
                                    if (!empty($row_tests)) {
                                        foreach ($row_tests as $key => $value_array) {
                                            ?>
                                            <label style="color:black;font-size: 13px;font-family: calibri;"><?php echo $count . " - " . $value_array['name']; ?></label><br>
                                            <?php
                                            $count++;
                                        }
                                    } else {
                                        ?>
                                        <label style="color:black;font-size: 13px;font-family: calibri;">No tests recommended</label>
                                        <?php
                                    }
                                    ?>

                                </div>
                                </div>
                            </div>
                        </div>
                     </div>
                    <!--<hr/>-->
                    <div class="row">
                        <div class="col-md-12"> 
                            <h5 style="color:black;font-size: 18px;font-family: calibri light;"><b>Prescribed Medicine(s)</b></h5>
                            <!--<hr>-->
                            <!--<br>-->
                            <div class="row">
                                <div class="col-md-6">
                                    <!--<label style="color:black;"><b>Prescribed Medicines to Patient: </b></label>-->
                                    <!--<br>-->
                                    <table  style="width:100%;border: 1px solid black;border-collapse: collapse;" >
                                        <thead>
                                            <tr>
                                                <th style="color:black;font-size: 12px;font-family: calibri;font-weight:bold;border: 1px solid black;border-collapse: collapse;">&nbsp;&nbsp;Sr. No.</th>
                                                <th style="color:black;font-size: 12px;font-family: calibri;font-weight:bold;border: 1px solid black;border-collapse: collapse;">&nbsp;&nbsp;Medicine Name</th>
                                                <th style="color:black;font-size: 12px;font-family: calibri;font-weight:bold;border: 1px solid black;border-collapse: collapse;">&nbsp;&nbsp;Form</th>
                                                <th style="color:black;font-size: 12px;font-family: calibri;font-weight:bold;border: 1px solid black;border-collapse: collapse;">&nbsp;&nbsp;Strength</th>
                                                <th style="color:black;font-size: 12px;font-family: calibri;font-weight:bold;border: 1px solid black;border-collapse: collapse;">&nbsp;&nbsp;Method</th>
                                                <th style="color:black;font-size: 12px;font-family: calibri;font-weight:bold;border: 1px solid black;border-collapse: collapse;">&nbsp;&nbsp;Days</th>
                                                <!--<th style="color:black;font-size: 12px;font-family: calibri;margin-left:5%;">Notes</th>-->
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $count = 1;
                                        if(isset($row_medicines) && !empty($row_medicines)){
                                            foreach ($row_medicines as $key => $value_array) {
                                                ?>
                                                <tr>
                                                    <td style="color:black;font-size: 12px;font-family: calibri;font-weight: normal;border: 1px solid black;border-collapse: collapse;">&nbsp;&nbsp;<?php echo $count ?></td>
                                                    <td style="color:black;font-size: 12px;font-family: calibri;font-weight: normal;border: 1px solid black;border-collapse: collapse;">&nbsp;&nbsp;<?php echo $value_array['generic_name']; ?></td>
                                                    <td style="color:black;font-size: 12px;font-family: calibri;font-weight: normal;border: 1px solid black;border-collapse: collapse;">&nbsp;&nbsp;<?php echo $value_array['dose']; ?></td>
                                                    <td style="color:black;font-size: 12px;font-family: calibri;font-weight: normal;border: 1px solid black;border-collapse: collapse;">&nbsp;&nbsp;<?php echo $value_array['strength']; ?></td>
                                                    <td style="color:black;font-size: 12px;font-family: calibri;font-weight: normal;border: 1px solid black;border-collapse: collapse;">&nbsp;&nbsp;<?php echo $value_array['repetition']; ?></td>
                                                    <td style="color:black;font-size: 12px;font-family: calibri;font-weight: normal;border: 1px solid black;border-collapse: collapse;">&nbsp;&nbsp;<?php echo $value_array['days']; ?></td>
                                                    <!--<td style="color:black;font-size: 12px;font-family: calibri;margin-left:5%;"><?php // echo $value_array['notes']; ?></td>-->
                                                </tr>
                                                <?php
                                                $count++;
                                            }
                                        }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                    <br><br><br><br><br>
                    <div class="text-center m-t-0 m-b-15">
                        <h5 style="color:black;font-size: 12px;font-family: calibri;"><b>Note : </b> <?php echo 'This is system generated prescription from “Doctor’s Hub” and doesn’t need signatures'; ?></h5>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-12 col-md-offset-5">
                            <input id="printPageButton" type="button" class="btn btn-success" onclick="printDiv('print_div')" value="Print Precription" />
                            <a id="gotoparentpage" class="btn btn-primary" style="color:white" href="<?php echo base_url("patients/search_patients") ?>">Go to patients list</a>

                        </div>
                    </div>
                </div>

            </div>
            </div>
                    </div>
                 </div>
        <!-- /.row --> 
<!-- /.container-fluid -->
