
<!-- Page Content -->
<div class="page-wrapper">
    <div class="container-fluid">
        <!-- .row -->
        <div class="row">
            <div class="col-md-12">
                <div class="white-box">
                    <h3 class="box-title">Patient Checkup</h3>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="white-box"> 
                                <div class="row line-steps">
                                    <a href="<?php
                                    if (isset($patient_id))
                                        echo "index?patient_id=" . $patient_id;
                                    else
                                        echo '#';
                                    ?>">
                                        <div class="col-md-3 column-step start"> 
                                            <div class="step-number">1</div>
                                            <div class="step-title">Patient Information</div>
                                            <div class="step-info">(Basic information)</div> 
                                        </div>
                                    </a>
                                    <a href="<?php
                                    if (isset($patient_id))
                                        echo "add_patient?patient_id=" . $patient_id . "&visit_id=" . $visit_id;
                                    else
                                        echo '#';
                                    ?>">
                                        <div class="col-md-3 column-step previous">
                                            <div class="step-number">2</div>
                                            <div class="step-title">Patient Vitals</div>
                                            <div class="step-info">(Heart,pulse rate etc.)</div>
                                        </div>
                                    </a>
                                    <a href="<?php
                                    if (isset($visit_id))
                                        echo "add_patient_readings?patient_id=" . $patient_id . "&visit_id=" . $visit_id;
                                    else
                                        echo '#';
                                    ?>">
                                        <div class="col-md-3 column-step previous">
                                            <div class="step-number">3</div>
                                            <div class="step-title">Clinical Diagnosis & Lab Order</div>
                                            <div class="step-info">(Disease patient is suffering from)</div>
                                        </div>
                                    </a>
                                    <div class="col-md-3 column-step active finish">
                                        <div class="step-number">4</div>
                                        <div class="step-title">Prescribe Medicines</div>
                                        <div class="step-info">(Prescribe suitable medicines)</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading"> Prescribe Medicines
                                </div>
                                <div class="panel-wrapper collapse in" aria-expanded="true">
                                    <div class="panel-body">
                                        <form method="POST" action="" class="form-horizontal form-bordered" name="medicine_prescription" id="medicine_prescription" onsubmit="return false;">
                                            <div class="form-body">
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>Medicine</label>
                                                            <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                                <select class="form-control select2 " id="medicine" name="medicine" required data-placeholder="Select">
                                                                    <option value="">Select</option>
                                                                    <?php
                                                                    if (isset($medicines)) {

                                                                        foreach ($medicines as $row) {
                                                                            $sel = '';
                                                                            if ($form['gender'] == $row['pk_id']) {
                                                                                $sel = "selected=selected";
                                                                            }
                                                                            ?>
                                                                            <option value="<?php echo $row['pk_id']; ?>" <?php echo $sel; ?>><?php echo $row['generic_name']; ?></option>
                                                                            <?php
                                                                        }
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>Dose Form</label>
                                                            <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                                <select class="form-control select2" id="dose_form" name="dose_form" required>
                                                                    <option value="">Select</option>
                                                                    <?php
                                                                    if (isset($dose)) {

                                                                        foreach ($dose as $row) {
                                                                            $sel = '';
                                                                            ?>
                                                                            <option value="<?php echo $row['pk_id']; ?>" <?php echo $sel; ?>><?php echo $row['dose_form']; ?></option>
                                                                            <?php
                                                                        }
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>Strength</label>
                                                            <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                                <select class="form-control select2" id="strength" name="strength" required>
                                                                    <option value="">Select</option>
                                                                    <?php
                                                                    if (isset($strength)) {

                                                                        foreach ($strength as $row) {
                                                                            $sel = '';
                                                                            ?>
                                                                            <option value="<?php echo $row['pk_id']; ?>" <?php echo $sel; ?>><?php echo $row['strength']; ?></option>
                                                                            <?php
                                                                        }
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>

                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>Method</label>
                                                            <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                                <select class="form-control" id="method" name="method" required>
                                                                    <?php
                                                                    $method = array("(Daily 1 – Any Time)", "(Daily 2 – Anytime)", "1+0+0+0 (M, A, E, N)", "1+1+0+0(M, A, E, N)", "1+1+1+0(M, A, E, N)", "1+1+1+1(M, A, E, N)", "0+1+0+0(M, A, E, N)", "0+1+1+0(M, A, E, N)", "0+1+1+1(M, A, E, N)", "0+1+1+0(M, A, E, N)", "0+1+0+1(M, A, E, N)", "0+0+1+0(M, A, E, N)", "0+0+0+1(M, A, E, N)", "0+0+1+1(M, A, E, N)");
                                                                    foreach ($method as $row) {
                                                                        $sel = '';
                                                                        if ($form['gender'] == $row) {
                                                                            $sel = "selected=selected";
                                                                        }
                                                                        ?>
                                                                        <option value="<?php echo $row; ?>" <?php echo $sel; ?>><?php echo $row; ?></option>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </select>
                                                                <span style="font-size: 12px;">(M – Morning, A  - Afternoon, E-Evening, N-Night) </span>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>No. of Days</label>
                                                            <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                                <select class="form-control" id="days" name="days" required>
                                                                    <option value="">Select</option>
                                                                    <?php
                                                                    $method = array("1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "15", "20", "21", "30");
                                                                    foreach ($method as $row) {
                                                                        $sel = ''; 
                                                                        ?>
                                                                        <option value="<?php echo $row; ?>" <?php echo $sel; ?>><?php echo $row; ?></option>
                                                                        <?php
                                                                    }
                                                                    ?>
                                                                </select> 
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="col-md-4">
                                                        <div class="form-group">
                                                            <label>Additional Notes</label>
                                                            <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-speech"></i></div>
                                                                <textarea class="form-control" id="notes" name="notes"></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div> 

                                                <div class="row">
                                                    <div class="col-md-12 col-md-offset-4">
                                                        <a style="color:white;" href='<?php if (isset($patient_id))
                                                                        echo "add_patient_readings?patient_id=" . $patient_id . "&visit_id=" . $visit_id;
                                                                    else
                                                                        echo "#";
                                                                    ?>' class="btn btn-primary">Back</a>
                                                        <button type="submit" id="final_submit" name="final_submit" class="btn btn-success">Add</button>
                                                        <a style="color:white;" href='<?php if (isset($visit_id))
                                                                        echo base_url("patients/print_prescription?visit_id=$visit_id&patient_id=$patient_id");
                                                                    else
                                                                        echo "#";
                                                                    ?>' id="print_prescription" name="print_prescription" class="btn btn-primary disable-click">Save & Print Prescription</a>
                                                        <a class="btn btn-warning disable-click" style="color:white;pointer-events: none;" href="<?php echo base_url("patients/search_patients") ?>">Save & Go to Menu</a>

                                                    </div>
                                                </div>
                                            </div>
                                            <input type="hidden" name="patient_id" value="<?php if (isset($patient_id)) echo $patient_id; ?>">
                                            <input type="hidden" name="visit_id" value="<?php if (isset($visit_id)) echo $visit_id; ?>">

                                            <input type="hidden" name="meddicine_string" id="medicine_string" value="">
                                            <input type="hidden" name="contradict_msg" id="contradict_msg" value="">
                                        </form>
                                        <table class="table color-bordered-table info-bordered-table" style="margin-top:5%;">
                                            <thead>
                                            <th>Medicine</th>
                                            <th>Dose Form</th>
                                            <th>Strength</th>
                                            <th>Method</th>
                                            <th>No. of days</th>
                                            <th>Action</th>
                                            <th>Contradiction Message</th>
                                            </thead>
                                            <tbody id="table_medicine">
                                            </tbody>
                                        </table>
                                        <!--<span id="toaster_info"></span>-->
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- /.row --> 
    </div>
    <!-- /.container-fluid -->
