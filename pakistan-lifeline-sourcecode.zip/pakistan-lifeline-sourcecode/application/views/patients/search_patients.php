
<!-- Page Content -->
<div class="page-wrapper" >
    <div class="container-fluid">
        <!-- .row -->
        <div class="row">
            <div class="col-sm-12">
                <div class="white-box">
                    <h3 class="box-title m-b-0">Search Patients</h3> 
                    <br>
                    <div class="row">

                        <form name="search_form" id="search_form" action="<?php echo base_url("patients/search_patients") ?>" method="post">
                            <div class="form-body">
                                <div class="col-md-3 col-md-offset-2">
                                    <div class="form-group">
                                        <label><b> Search by Patient MR#</b>
                                        </label>
                                        <div class="">
                                            <input class="form-control" type="number" value="<?= @$searched_text_mr ?>" id="search_text_mr" name="search_text_mr">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="form-group">
                                        <label><b> Search by Contact#</b>
                                        </label>
                                        <div class="">
                                            <input class="form-control" type="text" value="<?= @$searched_text_contact ?>" id="search_text_contact" name="search_text_contact">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <div class="input-group">
                                            <input id="search_btn" class="btn btn-success" value="Search" type="submit" style="margin-top: 35%"/>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                    
                    <?php if (!empty($searched_text_mr) || !empty($searched_text_contact)) { ?>
                    <div class="table-responsive">
                        <table id="search_table" class="display  table table-condensed" cellspacing="0" width="100%">
                            <thead>
                            <th>S. No.</th>
                            <th>MR Number</th>
                            <th>Prescription Number</th>
                            <th>Patients Name</th> 
                            <th>CNIC Number</th>
                            <th>Mobile Number</th>
                            <th>Visited On</th>
                            <th class='notexport'>Action</th>
                            </thead>
                            <tbody>
                                <?php
                                if (isset($searched_data) && !empty($searched_data)) {
                                    $count = 1;
                                    foreach ($searched_data as $value) {
                                        ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td>
                                            <td> <?php echo "MR-" . $value['patient_id'] ?> </td>
                                            <td> <?php echo "PR-" . $value['visit_id'] ?> </td>
                                            <td> <?php echo $value['full_name'] ?> </td> 
                                            <td> <?php echo $value['nic_no'] ?> </td>
                                            <td> <?php echo $value['mobile_no'] ?> </td>
                                            <td> <?php echo $value['visiting_date'] ?> </td>
                                            <td>
                                                <a class="btn btn-primary" href="<?php echo base_url("patients/add_patient?patient_id=" . $value['patient_id']) ?>">Add new visit</a>
                                                <br><br>
                                                <a class="btn btn-success" href="<?php echo base_url("patients/print_prescription?patient_id=" . $value['patient_id'] . "&visit_id=" . $value['visit_id']) ?>">Print Prescription</a>
                                                <br><br>
                                                <a class="btn btn-warning" href="<?php echo base_url("patients/index?patient_id=" . $value['patient_id'] . "&visit_id=" . $value['visit_id']."&edit=true") ?>">Edit Patient Details</a>

                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                    <?php } ?>
                </div>

            </div>
        </div>
        <!-- /.row --> 
    </div>
</div>
<!-- /.container-fluid -->
