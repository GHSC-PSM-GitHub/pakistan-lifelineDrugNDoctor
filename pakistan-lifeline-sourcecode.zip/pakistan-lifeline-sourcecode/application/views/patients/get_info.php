<?php if (isset($searched_data)) { ?>
    <table id="search_table" class="display  table table-condensed" cellspacing="0">
        <thead>
            <th colspan="2">S. No.</th>
            <th>MR Number</th>
            <th>Patients Name</th>
            <th>CNIC Number</th>
            <th>Mobile Number</th>
            <!--<th class='notexport'>Action</th>-->
        </thead>
        <tbody>
            <?php

            $count = 1;
            foreach ($searched_data as $value) {
            ?>
                <tr>
                    <?php if(ucfirst($name) == $value['full_name'] && $phone == $value['mobile_no']) {?>
                    <td>
                        <label for="checkid"  style="word-wrap:break-word" >
                            <input id="checkidmr" name="checkidmr[]"  type="checkbox" value="<?php echo  $value['pk_id']; ?>" style="vertical-align:middle;" checked/>
                        </label>     
                    </td>
                    <?php } else { ?>
                    <td>
                        <label for="checkid"  style="word-wrap:break-word" >
                            <input id="checkidmr" name="checkidmr[]"  type="checkbox" value="<?php echo  $value['pk_id']; ?>" style="vertical-align:middle;"/>
                        </label>     
                    </td>
                    <?php } ?>
                    <td><?php echo $count++; ?></td>
                    <td> <?php echo "MR-" . $value['pk_id'] ?> </td>
                    <td> <?php echo $value['full_name'] ?> </td>
                    <td> <?php echo $value['nic_no'] ?> </td>
                    <td> <?php echo $value['mobile_no'] ?> </td>
<!--                    <td>
                        <a class="btn btn-warning" href="<?php echo base_url("patients/index?patient_id=" . $value['pk_id'] . "&edit=true") ?>">Update</a>
                        <a class="btn btn-warning" id="update_patient_reg" name="update_patient_reg">Update</a>
                    </td>-->
                </tr>
            <?php
            }

            ?>
        </tbody>
    </table>
<?php } ?>