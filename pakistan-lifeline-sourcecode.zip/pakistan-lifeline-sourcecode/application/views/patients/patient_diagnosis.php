<?php
if (isset($diagnosis_data)) {

    foreach ($diagnosis_data as $key => $data_array) {
        $diagnosed_array[] = $data_array['diagnosis_id'];
        $notes = $data_array['notes'];
    }
}
if(isset($test_data)){
    foreach ($test_data as $key => $test_data_array) {
        $tests_array[] = $test_data_array['test_id'];
    }
}
?>
<!-- Page Content -->
<div class="page-wrapper">
    <div class="container-fluid">
        <!-- .row -->
        <div class="row">
            <div class="col-md-12">
                <div class="white-box">
                    <h3 class="box-title">Patient Checkup</h3>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="white-box"> 
                                <div class="row line-steps">
                                    <div class="col-md-3 column-step start">
                                       <a href="<?php if (isset($patient_id)) echo "index?patient_id=" . $patient_id;
else echo '#'; ?>">
                                            <div class="step-number">1</div>
                                            <div class="step-title">Patient Information</div>
                                            <div class="step-info">(Basic information)</div>
                                        </a>
                                    </div>
                                    <a href="<?php
                                    if (isset($patient_id))
                                        echo "add_patient?patient_id=" . $patient_id . "&visit_id=" . $visit_id;
                                    else
                                        echo '#';
                                    ?>">
                                        <div class="col-md-3 column-step previous">
                                            <div class="step-number">2</div>
                                            <div class="step-title">Patient Vitals</div>
                                            <div class="step-info">(Heart,pulse rate etc.)</div>
                                        </div>
                                    </a>
                                    <div class="col-md-3 column-step active">
                                        <div class="step-number">3</div>
                                        <div class="step-title">Clinical Diagnosis & Lab Order</div>
                                        <div class="step-info">(Disease patient is suffering from)</div>
                                    </div>
                                    <div class="col-md-3 column-step  finish">
                                        <div class="step-number">4</div>
                                        <div class="step-title">Prescribe Medicines</div>
                                        <div class="step-info">(Prescribe suitable medicines)</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading"> Clinical Diagnosis & Lab Order
                                </div>
                                <div class="panel-wrapper collapse in" aria-expanded="true">
                                    <div class="panel-body">
                                        <form method="POST" action="<?php echo base_url("patients/add_patient_diagnosis") ?>" class="form-horizontal form-bordered" name="patient_diagnosis" id="patient_diagnosis">
                                            <div class="form-body">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Diagnosed Disease<span style="color:red">*</span></label>
                                                            <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                                <select class="select2 m-b-10 select2-multiple" multiple="multiple" data-placeholder="Select" id="disease" name="disease[]" required style="width:75%;">
                                                                     <?php
                                                                    if (isset($diseases)) {

                                                                        foreach ($diseases as $disease) {
                                                                            $sel = '';
                                                                            foreach ($diagnosed_array as $value) {
                                                                                if ($value == $disease['pk_id']) {
                                                                                    $sel = "selected=selected";
                                                                                }
                                                                            }
                                                                            ?>
                                                                            <option value="<?php echo $disease['pk_id']; ?>" <?php echo $sel; ?>><?php echo $disease['disease_name']; ?></option>
                                                                            <?php
                                                                        }
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <div class="col-md-6">
                                                        <div class="form-group">
                                                            <label>Clinical Test Order</label>
                                                            <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                                <select class="select2 m-b-10 select2-multiple" multiple="multiple" data-placeholder="Select" id="tests" name="tests[]" style="width:75%;">
                                                                    <?php
                                                                    if (isset($tests)) {

                                                                        foreach ($tests as $row) {
                                                                            $sel = '';
                                                                            foreach ($tests_array as $value) {
                                                                                if ($value == $row['pk_id']) {
                                                                                    $sel = "selected=selected";
                                                                                }
                                                                            }
                                                                            ?>
                                                                            <option value="<?php echo $row['pk_id']; ?>" <?php echo $sel; ?>><?php echo $row['name']; ?></option>
                                                                            <?php
                                                                        }
                                                                    }
                                                                    ?>
                                                                </select>
                                                            </div>
                                                        </div>

                                                    </div>
                                                    <div class="col-md-12">
                                                        <div class="form-group">
                                                            <label>Additional Notes</label>
                                                            <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-speech"></i></div>
                                                                <textarea class="form-control" id="notes" name="notes"><?php if (isset($notes)) echo $notes; ?></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12 col-md-offset-5">
                                                        <a style="color:white;" href='<?php if (isset($patient_id)) echo "add_patient?patient_id=" . $patient_id . "&visit_id=" . $visit_id;
                                                                    else echo "#"; ?>' class="btn btn-primary">Back</a>
                                                        <button type="submit" id="second_submit" name="second_submit" class="btn btn-success">Next</button>
                                                    
                                                    </div>
                                                </div>
                                            </div>
                                            <input type="hidden" name="patient_id" value="<?php if (isset($patient_id)) echo $patient_id; ?>">
                                            <input type="hidden" name="visit_id" value="<?php if (isset($visit_id)) echo $visit_id; ?>">

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- /.row --> 
    </div>
    <!-- /.container-fluid -->
