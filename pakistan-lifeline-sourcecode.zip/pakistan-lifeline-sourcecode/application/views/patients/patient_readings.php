<?php
if (isset($visit_data)) {
    $row = $visit_data[0];
    $temperature = $row['temperature'];
    $bp_up = $row['bp_upper'];
    $bp_low = $row['bp_lower'];
    $heart_Rate = $row['pulse'];
    $notes = $row['other'];
    $visit_id = $row['pk_id'];
//    $patient_id = $patient_id[0];
}
else if(empty($visit_data) && isset($vital_info) && !empty($vital_info))
{
    $row = $vital_info[0];
    $temperature = $row['temperature'];
    $bp_up = $row['bp_upper'];
    $bp_low = $row['bp_lower'];
    $heart_Rate = $row['pulse'];
    $notes = $row['other'];
    $visit_id = $row['pk_id'];
//    $patient_id = $patient_id[0];
}
    
?>
<!-- Page Content -->
<div class="page-wrapper">
    <div class="container-fluid">
        <!-- .row -->
        <div class="row">
            <div class="col-md-12">
                <div class="white-box">
                    <h3 class="box-title">Patient Checkup</h3>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="white-box"> 
                                <div class="row line-steps">
                                    <div class="col-md-3 column-step start">
                                        <a href="<?php
                                        if (isset($patient_id))
                                            echo "index?patient_id=" . $patient_id;
                                        else
                                            echo '#';
                                        ?>">
                                            <div class="step-number">1</div>
                                            <div class="step-title">Patient Information</div>
                                            <div class="step-info">(Basic information)</div>
                                        </a>
                                    </div>
                                    <div class="col-md-3 column-step active">
                                        <div class="step-number">2</div>
                                        <div class="step-title">Patient Vitals</div>
                                        <div class="step-info">(Heart,pulse rate etc.)</div>
                                    </div>
                                    <div class="col-md-3 column-step ">
                                        <div class="step-number">3</div>
                                        <div class="step-title">Clinical Diagnosis & Lab Order</div>
                                        <div class="step-info">(Disease patient is suffering from)</div>
                                    </div>
                                    <div class="col-md-3 column-step finish">
                                        <div class="step-number">4</div>
                                        <div class="step-title">Prescribe Medicines</div>
                                        <div class="step-info">(Prescribe suitable medicines)</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading"> Patients' Vitals
                                </div>
                                <div class="panel-wrapper collapse in" aria-expanded="true">
                                    <div class="panel-body">
                                        <form method="POST" action="<?php echo base_url("patients/add_patient_readings") ?>" class="form-horizontal form-bordered" name="patient_readings" id="patient_readings">
                                            <div class="form-body">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>Temperature (Farenheit)</label>
                                                                <div class="input-group">
                                                                    <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                                    <input type="number" class="form-control" placeholder="Range 90 to 105" id="temperature" name="temperature" value="<?php if (isset($temperature)) echo $temperature; ?>" > 
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>BP Systolic Reading (Upper mmHg)</label>
                                                                <div class="input-group">
                                                                    <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                                    <input type="number" class="form-control" id="bp_systolic" placeholder="Max Value = 200" name="bp_systolic" value="<?php if (isset($bp_up)) echo $bp_up; ?>" > 
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>


                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>BP Diastolic Reading (Lower mmHg)</label>
                                                                <div class="input-group">
                                                                    <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                                    <input type="number" class="form-control" id="bp_diastolic" placeholder="Max Value = 200" name="bp_diastolic" value="<?php if (isset($bp_low)) echo $bp_low; ?>" > 
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>Heart Pulse (Beats per minute)</label>
                                                                <div class="input-group">
                                                                    <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                                    <input type="number" class="form-control" id="heart_pulse" placeholder="Max Value = 220" name="heart_pulse" value="<?php if (isset($heart_Rate)) echo $heart_Rate; ?>" > 
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-12">
                                                            <div class="form-group">
                                                                <label>Additional Notes</label>
                                                                <div class="input-group">
                                                                    <div class="input-group-addon"><i class="icon-speech"></i></div>
                                                                    <textarea class="form-control" id="notes" name="notes"><?php if (isset($notes)) echo $notes; ?> </textarea>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12 col-md-offset-5">
                                                        <a style="color:white;" href='<?php
                                                        if (isset($patient_id))
                                                            echo "index?patient_id=" . $patient_id . "&visit_id=" . $visit_id;
                                                        else
                                                            echo "#";
                                                        ?>' class="btn btn-primary">Back</a>

                                                        <button type="submit" id="second_submit" name="second_submit" class="btn btn-success"><?php
                                                                                                                                                if (isset($edit)) {
                                                                                                                                                    echo 'Save';
                                                                                                                                                } else {
                                                                                                                                                    echo 'Next';
                                                                                                                                                }
                                                                                                                                                ?></button>

                                                    </div>
                                                </div>
                                                <input type="hidden" name="patient_id" value="<?php if (isset($patient_id)) echo $patient_id; ?>">
                                                <?php if (isset($edit)) { ?>
                                                <input type="hidden" name="edit" value="<?php if (isset($edit)) echo $edit; ?>">
                                                <?php } ?>
                                                <?php if (isset($visit_data)) { ?>
                                                    <input type="hidden" name="visit_id" value="<?php if (isset($visit_id)) echo $visit_id; ?>">
                                                <?php } ?>
                                                </form>
                                            </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
            <!-- /.row --> 
        </div>
        <!-- /.container-fluid -->
