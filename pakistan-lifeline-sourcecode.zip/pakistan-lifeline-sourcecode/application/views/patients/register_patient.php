<?php
$years = "";
if (isset($patient_data)) {
    $row = $patient_data[0];
    $name = $row['full_name'];
    $genders = $row['gender'];
    $cnic_number = $row['nic_no'];
    $contact_number = $row['mobile_no'];
    $prov_id = $row['province_id'];
    $dist_id = $row['district_id'];
    $teh_id = $row['tehsil_id'];
    $uc_id = $row['uc_id'];
    $string = $row['age'];
    $districts = $districts->result_object();
    $tehsils = $tehsils->result_object();
    $ucs = $ucs->result_object();
    $str_arr = str_replace("-",",",$string);
    $age = explode (",", $str_arr);
    $diff = abs(strtotime(date("Y-m-d"))-strtotime($string));
    $years = floor($diff / (365*60*60*24));
//    print_r();
    $email = $row['email'];
    $patient_id = $row['pk_id'];
//    print_r($age);
}
?>
<?php
if($this->session->flashdata('contact_number'))    
{   
    $name = $this->session->flashdata('full_name');
    $contact_number = $this->session->flashdata('contact_number');
    $genders = $this->session->flashdata('gender');
    $cnic_number = $this->session->flashdata('cnic_number');
    $years = $this->session->flashdata('age');
    $dob = $this->session->flashdata('dob');
    $prov_id = $this->session->flashdata('prov');
    $dist_id = $this->session->flashdata('dist');
    $teh_id = $this->session->flashdata('teh');
    $uc_id = $this->session->flashdata('uc');
    $districts = $this->session->flashdata('districts');
//    print_r($districts);
    $tehsils = $this->session->flashdata('tehsils');
    $ucs = $this->session->flashdata('ucs');
    $a = implode("-",$dob);
    $b = date("Y-m-d", strtotime($a));
    $str_arr = str_replace("-",",",$b);
    $age = explode (",", $str_arr);
//    print_r($age);
    $email = $this->session->flashdata('email');
?>
<script type="text/javascript">
        alert('Patient exist with same contact no and name.');
//        alert('<?php // echo $name; ?>');
</script>
<?php
} else {
    
}
?>
<!-- Page Content -->
<div class="page-wrapper">
    <div class="container-fluid">
        <!-- .row -->
        <div class="row">
            <div class="col-md-12">
                <div class="white-box">
                    <h3 class="box-title">Patient Checkup</h3>
                    <div class="row">
                        <div class="col-md-12">
                            <div class="white-box">
                                <div class="row line-steps">
                                    <div class="col-md-3 column-step active">
                                        <div class="step-number">1</div>
                                        <div class="step-title">Patient Information</div>
                                        <div class="step-info">(Basic information)</div>
                                    </div>
                                    <div class="col-md-3 column-step ">
                                        <div class="step-number">2</div>
                                        <div class="step-title">Patient Vitals</div>
                                        <div class="step-info">(Heart,pulse rate etc.)</div>
                                    </div>
                                    <div class="col-md-3 column-step ">
                                        <div class="step-number">3</div>
                                        <div class="step-title">Clinical Diagnosis & Lab Order</div>
                                        <div class="step-info">(Disease patient is suffering from and tests to be performed)</div>
                                    </div>
                                    <div class="col-md-3 column-step finish">
                                        <div class="step-number">4</div>
                                        <div class="step-title">Prescribe Medicines</div>
                                        <div class="step-info">(Prescribe suitable medicines)</div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                     <!--<div id="infoMessage"><?php // echo $this->session->flashdata('message');?></div>-->
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading"> Patients' Basic Information
                                </div>
                                <div class="panel-wrapper collapse in" aria-expanded="true">
                                    <div class="panel-body">
                                        <form method="POST" action="<?php echo base_url("patients/add_patient") ?>" class="form-horizontal form-bordered" name="patient_info" id="patient_info">
                                            <div class="form-body">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>Full Name <span style="color:red">*</span></label>
                                                                <div class="input-group">
                                                                    <div class="input-group-addon"><i class="ti-user"></i></div>
                                                                    <input type="text" class="form-control" id="full_name" placeholder="Patient Name" name="full_name"  value="<?php if (isset($name)) echo $name; ?>" minlength="5">
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>Contact Number <span style="color:red">*</span></label>
                                                                <div class="input-group">
                                                                    <div class="input-group-addon"><i class="icon-phone"></i></div>
                                                                    <input type="text" class="form-control" id="contact_number" name="contact_number" placeholder="03XXXXXXXXX" value="<?php if (isset($contact_number)) echo $contact_number; ?>">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>Gender <span style="color:red">*</span></label>
                                                                <div class="input-group">
                                                                    <div class="input-group-addon"><i class="icon-people"></i></div>
                                                                    <select class="form-control" id="gender" name="gender">
                                                                        <?php
                                                                        $gender = array("Male", "Female", "Transgender");
                                                                        foreach ($gender as $gen) {
                                                                            $sel = '';
                                                                            if ($gen == $genders) {
                                                                                $sel = "selected=selected";
                                                                            }
                                                                        ?>
                                                                            <option value="<?php echo $gen; ?>" <?php echo $sel; ?>><?php echo $gen; ?></option>
                                                                        <?php
                                                                        }
                                                                        ?>
                                                                    </select>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>CNIC Number
                                                                    <!--<span style="color:red">*</span>-->
                                                                </label>
                                                                <div class="input-group">
                                                                    <div class="input-group-addon"><i class="icon-support"></i></div>
                                                                    <input type="text" class="form-control" id="cnic_number" placeholder="XXXXXXXXXXXX" name="cnic_number" value="<?php if (isset($cnic_number)) echo $cnic_number; ?>">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="row">
                                                    <div class="col-md-12">

                                                        <div class="col-md-6">

                                                            <div class="form-group">
                                                                <label>Age <span style="color:red">*</span></label>
                                                                <div class="input-group">
                                                                    <!--<div class="input-group-addon"><i class="icon-notebook"></i></div>-->
                                                                    <!--<input type="number" class="form-control" id="age" name="age" value="<?php // if (isset($age)) echo $age; ?>">-->
                                                                    <!--<div class="col-sm-6">-->
                                                                    <!--<div class="input-group">-->
                                                                    <span class="input-group-btn">
                                                                        <input type="text" name="age" id="age" onkeyup="calculate_age(this.value,'age2dob')"  class="form-control" value="<?php echo $years; ?>" placeholder="Age" />
                                                                    </span>
                                                                    <span class="input-group-btn">
                                                                        <select class="form-control" onchange="calculate_age(this.value,'dob2age')" id="day" name="dob[]" >
                                                                            <?php for ($d = 1; $d <= 31; $d++) {
                                                                                $sel = "";
                                                                                if ($d == $age['2']) {
                                                                                    $sel = "selected=selected";
                                                                                }
                                                                            ?>
                                                                                <option value="<?php echo $d; ?>" <?php echo $sel; ?>><?php echo $d; ?></option>
                                                                            <?php } ?>
                                                                        </select>
                                                                    </span>
                                                                    <span class="input-group-btn">
                                                                        <select class="form-control" onchange="calculate_age(this.value,'dob2age')" id="month" name="dob[]" >
                                                                            <?php for ($m = 1; $m <= 12; $m++) {
                                                                                $sel = "";
                                                                                if ($m == $age['1']) {
                                                                                    $sel = "selected=selected";
                                                                                }
                                                                            ?>
                                                                                <option value="<?php echo $m; ?>" <?php echo $sel; ?>><?php echo date('F', mktime(0, 0, 0, $m, 10)); ?></option>
                                                                            <?php } ?>
                                                                        </select>
                                                                    </span>
                                                                    <span class="input-group-btn">
                                                                        <select class="form-control" onchange="calculate_age(this.value,'dob2age')" id="year" name="dob[]" >
                                                                            <?php for ($y = 1910; $y <= date("Y"); $y++) {
                                                                                $sel = "";
                                                                                if ($y == $age['0']) {
                                                                                    $sel = "selected=selected";
                                                                                }
                                                                            ?>
                                                                                <option value="<?php echo $y; ?>" <?php echo $sel; ?>><?php echo $y; ?></option>
                                                                            <?php } ?>
                                                                        </select>
                                                                        </span>                                                                    
                                                                    <!--</div> input-group -->
                                                                    <!--</div>-->
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-6">
                                                            <div class="form-group">
                                                                <label>Email </label>
                                                                <div class="input-group">
                                                                    <div class="input-group-addon"><i class="icon-login"></i></div>
                                                                    <input type="text" class="form-control" id="email" name="email" placeholder="patient@email.com" value="<?php if (isset($email)) echo $email; ?>">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                    <div class="row">
                                        <div class="col-md-12">

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                        <label>Province: <span style="color: red;">*</span></label>
                                                        <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                            <select class="form-control select2" id="province" name="province" required>
                                                                <option value="">Select</option>
                                                                <?php $provinces = array(5 => "AJK", 4 => "Balochistan", 6 => "FATA", 7 => "Gilgit Baltistan", 8 => "Islamabad", 3 => "Khyber Pakhtunkhwa",1 => "Punjab", 2 => "Sindh");
                                                                foreach ($provinces as $key => $prov) {
                                                                    $sel = '';
                                                                    if ($prov_id == $key) {
                                                                        $sel = "selected=selected";
                                                                    }
                                                                ?>
                                                                    <option value="<?php echo $key; ?>" <?php echo $sel; ?>><?php echo $prov; ?></option>
                                                                <?php
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                            </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>District: <span style="color: red;">*</span></label>
                                                        <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                            <select class="form-control select2" id="district" name="district" required>
                                                                <?php
                                                                echo "<option value=>Select</option>";
                                                                if (isset($districts)) {
                                                                    foreach ($districts as $row) {
                                                                        $sel = '';
                                                                        if ($dist_id == $row->pk_id) {
                                                                            $sel = "selected=selected";
                                                                        }
                                                                        echo "<option value=" . $row->pk_id . " $sel >" . $row->location_name . "</option>";
                                                                    }
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>      
                                    <div class="row">
                                        <div class="col-md-12">

                                            <div class="col-md-6">
                                                <div class="form-group">
                                                        <label>Tehsil: <span style="color: red;">*</span></label>
                                                        <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                            <select class="form-control select2" id="tehsil" name="tehsil" required>
                                                                <?php
                                                                echo "<option value=>Select</option>";
                                                                if (isset($tehsils)) {
                                                                    foreach ($tehsils as $row) {
                                                                        $sel = '';
                                                                        if ($teh_id == $row->pk_id) {
                                                                            $sel = "selected=selected";
                                                                        }
                                                                        echo "<option value=" . $row->pk_id . " $sel>" . $row->location_name . "</option>";
                                                                    }
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                            </div>
                                            <div class="col-md-6">
                                                <div class="form-group">
                                                        <label>UC: <span style="color: red;">*</span></label>
                                                        <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                            <select class="form-control select2" id="uc" name="uc" required>
                                                                <?php
                                                                echo "<option value=>Select</option>";
                                                                if (isset($ucs)) {
                                                                    foreach ($ucs as $row) {
                                                                        $sel = '';
                                                                        if ($uc_id == $row->pk_id) {
                                                                            $sel = "selected=selected";
                                                                        }
                                                                        echo "<option value=" . $row->pk_id . " $sel>" . $row->location_name . "</option>";
                                                                    }
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                            </div>
                                        </div>
                                    </div>
                                                
                                                <div class="row">
                                                    <div class="col-md-12 col-md-offset-5">

                                                        <button type="button" id="second_submit" name="second_submit" class="btn btn-success"><?php
                                                                                                                                                if (isset($edit)) {
                                                                                                                                                    echo 'Save';
                                                                                                                                                } else {
                                                                                                                                                    echo 'Next';
                                                                                                                                                }
                                                                                                                                                ?></button>

                                                    </div>
                                                </div>
                                            </div>
                                            <input type="hidden" name="update_patient_id" id="update_patient_id" value="">
                                            <input type="hidden" name="patient_id_old" id="patient_id_old" value="">
<!--                                            <input type="hidden" name="dist_ids" id="dist_ids" value="">
                                            <input type="hidden" name="teh_ids" id="teh_ids" value="">
                                            <input type="hidden" name="uc_ids" id="uc_ids" value="">-->
                                            <input type="hidden" id="patient_ids" name="patient_id" value="<?php if (isset($patient_id)) echo $patient_id; ?>">
                                            <?php if (isset($edit)) { ?>
                                                <input type="hidden" name="edit" value="<?php if (isset($edit)) echo $edit; ?>">
                                            <?php } ?>
                                            <?php if (isset($visit_id))  ?>
                                            <input type="hidden" name="visit_id" value="<?php if (isset($visit_id)) echo $visit_id; ?>">

                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </div>
    <!-- /.container-fluid -->

    <span data-toggle="modal" data-target="#myModal" id="modal"></span>
    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog">

            <!-- Modal content-->
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                    <h4 class="modal-title">Following Records are found with same phone number</h4>
                </div>
                <div class="modal-body" id="same_record">
                    <p>Some text in the modal.</p>
                </div>
                <div class="modal-footer">
                    <button type="submit" id="second_skip" name="second_skip" class="btn btn-info" >Skip</button>
                    <button type="button" class="btn btn-info" data-dismiss="modal">Go Back</button>
                    <button type="submit" id="second_submit1" name="final_submit" class="btn btn-success">Add</button>
                    <button type="submit" id="update_patient_reg" name="update_patient_reg" class="btn btn-warning">Update</button>
                    <!--<a href="<?php echo base_url("/patients/search_patients"); ?>"><button type="button" class="btn btn-danger">Skip Registration</button></a>-->
                    
                </div>
            </div>

        </div>
    </div>