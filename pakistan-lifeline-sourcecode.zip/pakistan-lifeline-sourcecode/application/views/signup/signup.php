
<!-- Page Content -->
<div class="page-wrapper">
    <div class="container-fluid">
        <!-- .row -->
        <div class="row">
            <div class="col-md-12">
                <div class="white-box">
                    <h3 class="box-title">Register</h3> 
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-primary"> 
                            </div>
                            <div class="panel-wrapper collapse in" aria-expanded="true">
                                <div class="panel-body">
                                    <form method="POST" action="<?php echo base_url("welcome/save_signup") ?>" class="form-horizontal form-bordered" name="signup_deets" id="signup_deets">
                                        <div class="form-body">
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>Full Name <span style="color: red;">*</span></label>
                                                        <div class="input-group">
                                                            <div class="input-group-addon"><i class="ti-user"></i></div>
                                                            <input type="text" class="form-control" placeholder="Full Name" tabindex="1" id="full_name" name="full_name" required value="" minlength="5"> 
                                                        </div>
                                                    </div>
                                                    <div class="form-group"> 
                                                            <label>Contact Number <span style="color: red;">*</span></label>
                                                            <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-phone"></i></div>
                                                                <input type="text" class="form-control" placeholder="03XXXXXXXXX" tabindex="3" id="phone" required minlength="11" maxlength="11" name="phone" value=""> 
                                                            </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Email <span style="color: red;">*</span></label>
                                                        <div class="input-group">
                                                            <div class="input-group-addon"><i class="icon-login"></i></div>
                                                            <input type="text" class="form-control" tabindex="5" placeholder="xyz@email.com" id="email" name="email"  value=""> 
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Clinic Address <span style="color: red;">*</span></label>
                                                        <div class="input-group">
                                                            <div class="input-group-addon"><i class="icon-support"></i></div>
                                                            <textarea class="form-control" id="address" rows="1" tabindex="7" name="address" required> </textarea>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Province: <span style="color: red;">*</span></label>
                                                        <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                                <select class="form-control select2" id="province" name="province" tabindex="9" required>
                                                                <option value="">Select</option>
                                                                <?php $provinces = array(5 => "AJK", 4 => "Balochistan", 6 => "FATA", 7 => "Gilgit Baltistan", 8 => "Islamabad", 3 => "Khyber Pakhtunkhwa",1 => "Punjab", 2 => "Sindh");
                                                                foreach ($provinces as $key => $prov) {
                                                                    $sel = '';
                                                                    if ($form['province'] == $key) {
                                                                        $sel = "selected=selected";
                                                                    }
                                                                ?>
                                                                    <option value="<?php echo $key; ?>" <?php echo $sel; ?>><?php echo $prov; ?></option>
                                                                <?php
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>

                                                    <div class="form-group">
                                                        <label>Tehsil: <span style="color: red;">*</span></label>
                                                        <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                            <select class="form-control select2" id="tehsil" name="tehsil" tabindex="11" required>
                                                                <?php
                                                                echo "<option value=>Select</option>";
                                                                if (isset($tehsils)) {
                                                                    foreach ($tehsils->result_object() as $row) {
                                                                        $sel = '';
                                                                        if ($form['tehsil'] == $row->pk_id) {
                                                                            $sel = "selected=selected";
                                                                        }
                                                                        echo "<option value=" . $row->pk_id . " $sel>" . $row->location_name . "</option>";
                                                                    }
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    
<!--                                                    <div class="form-group" style="margin-top:10%;">
                                                        <label>Role</label>
                                                        <div class="input-group">
                                                            <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                            <select name="role" class="form-control" tabindex="7" required="">
                                                                <option value="">Select</option>
                                                                <option value="D">Doctor</option>
                                                                <option value="P">PMDC Approval User</option>
                                                                <option value="POS">Pharmacy User</option>
                                                            </select> 
                                                        </div>
                                                    </div>-->
                                                    
                                                    
                                                </div>
                                                <div class="col-md-6">
                                                    <div class="form-group">
                                                        <label>PMDC Number/User id <span style="color: red;">*</span></label>
                                                        <div class="input-group">
                                                            <div class="input-group-addon"><i class="icon-people"></i></div>
                                                            <input type="text" class="form-control" tabindex="2" id="pmdc_no" name="pmdc_no" placeholder="Please enter Alphabets, Numeric Digits and Hypen only." pattern="^[a-zA-Z0-9,-]+$" required> 

                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>CNIC Number
                                                            <span style="color:red">*</span>
                                                        </label>
                                                        <div class="input-group">
                                                            <div class="input-group-addon"><i class="icon-support"></i></div>
                                                            <input type="text" class="form-control" tabindex="4" id="cnic_number" placeholder="XXXXXXXXXXXX" required minlength="13" maxlength="13" name="cnic_number" value="<?php if (isset($cnic_number)) echo $cnic_number; ?>">
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Clinic Name <span style="color: red;">*</span></label>
                                                        <div class="input-group">
                                                            <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                            <input type="text" class="form-control" placeholder="Clinic Name" tabindex="6" id="clinic_name" name="clinic_name" value="" > 
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>Password <span style="color: red;">*</span></label>
                                                        <div class="input-group">
                                                            <div class="input-group-addon"><i class="ti-pencil"></i></div>
                                                            <input type="password" class="form-control" tabindex="8" id="password" name="password" required  minlength="5"> 
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>District: <span style="color: red;">*</span></label>
                                                        <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                            <select class="form-control select2" id="district" name="district" tabindex="10" required>
                                                                <?php
                                                                echo "<option value=>Select</option>";
                                                                if (isset($districts)) {
                                                                    foreach ($districts->result_object() as $row) {
                                                                        $sel = '';
                                                                        if ($form['district'] == $row->pk_id) {
                                                                            $sel = "selected=selected";
                                                                        }
                                                                        echo "<option value=" . $row->pk_id . " $sel >" . $row->location_name . "</option>";
                                                                    }
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                    <div class="form-group">
                                                        <label>UC: <span style="color: red;">*</span></label>
                                                        <div class="input-group">
                                                                <div class="input-group-addon"><i class="icon-notebook"></i></div>
                                                            <select class="form-control select2" id="uc" name="uc" tabindex="12" required>
                                                                <?php
                                                                echo "<option value=>Select</option>";
                                                                if (isset($ucs)) {
                                                                    foreach ($ucs->result_object() as $row) {
                                                                        $sel = '';
                                                                        if ($form['uc'] == $row->pk_id) {
                                                                            $sel = "selected=selected";
                                                                        }
                                                                        echo "<option value=" . $row->pk_id . " $sel>" . $row->location_name . "</option>";
                                                                    }
                                                                }
                                                                ?>
                                                            </select>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div> 
                                            <div class="row">
                                                <div class="col-md-12 col-md-offset-5">

                                                    <button type="submit" id="second_submit" name="second_submit" class="btn btn-success"> Register</button>

                                                </div>
                                            </div>
                                        </div>
                                        <input type="hidden" name="patient_id" value="<?php if (isset($patient_id)) echo $patient_id; ?>">
                                        <?php if (isset($edit)) { ?>
                                            <input type="hidden" name="edit" value="<?php if (isset($edit)) echo $edit; ?>">
                                        <?php } ?>
                                        <?php if (isset($visit_id))  ?>
                                        <input type="hidden" name="visit_id" value="<?php if (isset($visit_id)) echo $visit_id; ?>">

                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
    <!-- /.row --> 
</div>
<!-- /.container-fluid -->
