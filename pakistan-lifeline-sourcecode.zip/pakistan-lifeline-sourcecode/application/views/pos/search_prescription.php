
<!-- Page Content -->
<div class="page-wrapper" >
    <div class="container-fluid">
        <!-- .row -->
        <div class="row">
            <div class="col-sm-12">
                <div class="white-box">
                    <h3 class="box-title m-b-0">Search Prescription</h3> 
                    <div class="row">

                        <form name="search_form" id="search_form" action="<?php echo base_url("pos/search_prescription") ?>" method="post">
                            <div class="form-body">
                                <div class="col-md-6 col-md-offset-2">
                                    <div class="form-group">
                                        <label><b> Search by Prescription Number, Contact Number, CNIC and MR Number</b>
                                        </label>
                                        <div class="">
                                            <input class="form-control" type="text" value="<?= @$searched_text ?>" id="search_text" name="search_text">
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <div class="input-group">
                                            <input id="search_btn" class="btn btn-success" value="Search" type="submit" style="margin-top: 35%"/>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>

                    </div>
                        <br>
                        <div class="table-responsive">
                            
                            <?php if (!empty($searched_text)) { ?>
                            <div class="panel panel-success block5">
                                <div class="panel-heading"> Searched Data
                             </div>
                                <div class="panel-wrapper collapse in" aria-expanded="true">
                                <div class="panel-body">
                                <table id="search_table_without_btn" class="display nowrap" cellspacing="0" width="100%">
                                    <thead>
                                    <th style="width:1%">S. No.</th>
                                    <th style="width:10%">Prescription Number</th>
                                    <th>MR Number</th>
                                    <th>Patients Name</th>
                                    <th>Gender</th> 
                                    <th>Visited On</th>
                                    <th>Action</th>
                                    </thead>
                                    <tbody>
                                        <?php
                                        if (isset($searched_data)&&!empty($searched_data)) {
                                            $count = 1;
                                            foreach ($searched_data as $value) {
                                                ?>
                                                <tr>
                                                    <td><?php echo $count++; ?></td>
                                                    <td> <?php echo "PR-" . $value['visit_id'] ?> </td>
                                                    <td> <?php echo "MR-" . $value['patient_id'] ?> </td>
                                                    <td> <?php echo $value['full_name'] ?> </td>
                                                    <td> <?php echo $value['gender'] ?> </td> 
                                                    <td> <?php echo $value['visiting_date'] ?> </td>
                                                    <td> 
                                                        <a class="btn btn-success" style="color:white" href="<?php echo base_url("pos/billing?patient_id=" . $value['patient_id'] . "&visit_id=" . $value['visit_id']) ?>">Bill Prescription</a>
                                                    </td>
                                                </tr>
                                                <?php
                                            }
                                        }
                                        ?>
                                    </tbody>
                                </table>
                                </div>
                            </div>
                            </div>
                            <?php } ?>
                        </div>
                    </div>

                </div>
            </div>
            <!-- /.row --> 
        </div>
    </div>
    <!-- /.container-fluid -->
