
<!-- Page Content -->
<div class="page-wrapper" >
    <div class="container-fluid">
        <!-- .row -->
        <div class="row">
            <div class="col-sm-12">
                <div class="white-box">
                    <h3 class="box-title m-b-0">Search Bills</h3> 
                    <div class="table-responsive">
                        <table id="search_table" class="display nowrap" cellspacing="0" width="100%">
                            <thead>
                            <th>S. No.</th> 
                            <th>Medicine</th>
                            <th>Sale Quantity</th>
                            <th>Price</th>
                            <th>Created On</th> 
                            <th class='notexport'>Action</th>
                            </thead>
                            <tbody>
                                <?php
                                if (isset($searched_data)) {
                                    $count = 1;
                                    foreach ($searched_data as $value) {
                                        ?>
                                        <tr>
                                            <td><?php echo $count++; ?></td> 
                                            <td> <?php echo $value['generic_name'] ?> </td>
                                            <td> <?php echo $value['sale_quantity'] ?> </td>
                                            <td> <?php echo $value['price'] ?> </td>
                                            <td> <?php echo $value['created_date'] ?> </td> 
                                            <td> 
                                                <a class="btn btn-success" href="<?php echo base_url("pos/print_bill?visit_id=" . $value['visit_id']) ?>">Print Bill</a>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>
                            </tbody>
                        </table>
                    </div>
                </div>

            </div>
        </div>
        <!-- /.row --> 
    </div>
</div>
<!-- /.container-fluid -->
