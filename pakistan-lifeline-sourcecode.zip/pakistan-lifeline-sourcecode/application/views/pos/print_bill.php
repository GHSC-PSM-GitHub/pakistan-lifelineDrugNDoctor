<?php
if (isset($patient_medicines_info)) {
    $row_medicines = $patient_medicines_info;
//    print_r($row_medicines);
//    exit;
}
?>
<!-- Page Content -->
<div class="page-wrapper" id="print_div">
    <div class="container-fluid">
        <!-- .row -->
        <div class="row">
            <div class="col-md-12">
                <div class="white-box">
                    <h3 class="box-title" style="background-color: #eae6e6;padding: 2%;">Print Prescription</h3> 

                    <div class="row">
                        <div class="col-md-12"> 
                            <h5>Billing Information</h5>
                            <table class="table table-striped table-bordered">
                                <thead>
                                <th> Medicines</th>
                                <th>Quantity</th>
                                <th>Price</th>

                                </thead>
                                <tbody>
                                    <?php
                                    $total = 0;
                                    foreach ($row_medicines as $key => $value) {
                                        ?>
                                        <tr>
                                            <td><?php echo $value['generic_name'] ?></td>
                                            <td><?php echo $value['sale_quantity'] ?></td>
                                            <td><?php echo $value['price'] ?></td>
                                        </tr>
                                        <?php
                                        $total += ($value['sale_quantity'] * $value['price']);
                                        $balance = $value['balance'];
                                        $paid = $value['paid'];
                                    }
                                    ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <td colspan="2">Total</td>
                                        <td><?php echo $total ?></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">Balance</td>
                                        <td><?php echo $balance ?></td>
                                    </tr>
                                    <tr>
                                        <td colspan="2">Paid</td>
                                        <td><?php echo $paid ?></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-12 col-md-offset-5">
                            <input  type="button" class="btn btn-success" onclick="printDiv('print_div')" value="Print Bill" />
                            <a class="btn btn-primary" style="color:white" href="<?php echo base_url("pos/pharmacy_bills") ?>">Go to bills list</a>

                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- /.row --> 
    </div>
</div>
<!-- /.container-fluid -->
