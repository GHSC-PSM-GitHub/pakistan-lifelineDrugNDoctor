<?php
if (isset($patient_medicines_info)) {
//    print_r($patient_medicines_info);
//    exit;
}
?>
<!-- Page Content -->
<div class="page-wrapper">
    <div class="container-fluid">
        <!-- .row -->
        <div class="row">
            <div class="col-md-12">
                <div class="white-box">
                    <h3 class="box-title">Generate Bill</h3> 
                    <div class="row">
                        <div class="col-md-12">
                            <div class="panel panel-primary">
                                <div class="panel-heading"> Prescribe Medicines
                                </div>
                                <div class="panel-wrapper collapse in" aria-expanded="true">
                                    <div class="panel-body">
                                        <form method="POST" class="form-horizontal form-bordered" name="medicine_prescription" id="medicine_prescription" action="<?php echo base_url("pos/process_bill"); ?>">
                                            <div class="form-body">
                                                <table class="table table-bordered table-striped">
                                                    <thead>
                                                    <th>Medicine</th>
                                                    <th>Dose</th>
                                                    <th>Strength</th>
                                                    <th>Sale Quantity</th>
                                                    <th>Price</th>
                                                    <th>Amount</th>
                                                    </thead>
                                                    <tbody>
                                                        <?php
                                                        if (isset($patient_medicines_info)) {
                                                            foreach ($patient_medicines_info as $key => $value) {
                                                                ?>
                                                                <tr>
                                                                    <td><label><?php echo $value['generic_name'] ?></label></td> 
                                                                    <td> <label><?php echo $value['dose'] ?></label></td>
                                                                    <td> <label><?php echo $value['strength'] ?></label></td>
                                                                    <td><input type="number" class="form-control keyup" id="sale_qty-<?php echo $value['pk_id'] ?>" data-id="<?php echo $value['pk_id'] ?>" name="sale_qty[]" required>
                                                                    </td>
                                                                    <td>  <input type="number" class="form-control keyup" id="price-<?php echo $value['pk_id'] ?>" data-id="<?php echo $value['pk_id'] ?>" name="price[]" required/> 
                                                                    </td>
                                                                    <td> <input type="number" class="form-control amount-class" readonly="true" id="amount-<?php echo $value['pk_id'] ?>" name="amount" required/>
                                                                    </td>
                                                            <input type="hidden" name="patient_prescription_id[]" value="<?php echo $value['pk_id'] ?>">
                                                            </tr>

                                                            <?php ?> 
                                                            <input type="hidden" name="visit_id" value="<?php if ($value['visit_id']) echo $value['visit_id']; ?>">
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <td colspan="4"></td>
                                                            <td ><label style="text-align:right">Total</label></td>
                                                            <td><input type="number" name="total" id="total" class="form-control" readonly="true"></td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4"></td>
                                                            <td ><label style="text-align:right">Paid</label></td>
                                                            <td><input type="number" name="paid" id="paid" class="form-control"></td>
                                                        </tr>
                                                        <tr>
                                                            <td colspan="4"></td>
                                                            <td ><label style="text-align:right">Balance</label></td>
                                                            <td><input type="number" name="balance" id="balance" class="form-control" readonly="true"></td>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                                <div class="row">
                                                    <div class="col-md-12 col-md-offset-5">
                                                        <button type="submit" id="final_submit" name="final_submit" class="btn btn-success">Save</button>

                                                    </div>
                                                </div>

                                            </div>

                                        </form>

                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <!-- /.row --> 
    </div>
    <!-- /.container-fluid -->
