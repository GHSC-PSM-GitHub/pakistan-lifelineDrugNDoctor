
<!-- Page Content -->
<div class="page-wrapper" >
    <div class="container-fluid">
        <!-- .row -->
        <div class="row">
            <div class="col-sm-12">
                <div class="white-box">
                    <h3 class="box-title m-b-0">Approve Doctors</h3> 
                    <div class="table-responsive">
                        <form name="approve_form" id="approve_form" method="post" action="<?php echo base_url("pmdc/approve_doctors") ?>">
<!--                            <button style="margin-top:.75em;margin-bottom:.75em;width: 15%; height: 35px; font-size: 15px; float:right; margin-left: 20px;" type="submit" class="btn btn-success" >Reject List</button>
                            <button style="margin-top:.75em;margin-bottom:.75em;width: 15%; height: 35px; font-size: 15px; float:right; " type="submit" class="btn btn-success" >Approve List</button>-->
                            <br>
                            <input  style="margin-top:.75em;margin-bottom:.75em;width: 15%; height: 35px; font-size: 15px; float:right; margin-left: 20px;" type="submit" class="btn btn-success" id="rejlist" name="rejlist" value="Reject List" />
                            <input  style="margin-top:.75em;margin-bottom:.75em;width: 15%; height: 35px; font-size: 15px; float:right; " type="submit" class="btn btn-success" name="aprovlist" id="aprovlist" value="Approve List"/>  
                            <table id="search_table" class="display nowrap" cellspacing="0" width="100%">
                                <thead>
                                <th>S. No.</th>
                                <th>Full Name</th>
                                <th>Email id</th>
                                <th>PMDC Number</th> 
                                <th><input type="checkbox" id="checkAllapprove">Approve All</th>
                                <th><input type="checkbox" id="checkAllrej">Reject All</th>
                                </thead>
                                <tbody>

                                    <?php
                                    if (isset($pending_list)) {
                                        $count = 1;
                                        foreach ($pending_list as $value) {
                                            ?>
                                            <tr>
                                                <td><?php echo $count++; ?></td>
                                                <td> <?php echo $value['full_name'] ?> </td>
                                                <td> <?php echo $value['email'] ?> </td> 
                                                <td> <?php echo $value['pmdc_no'] ?> </td> 
                                                <td>
                                                    <input type="checkbox" id="approvelist" name="approve[]" class="btn btn-primary" value="<?php echo $value['pk_id'] ?>">
                                                    <label>Approve</label>
                                                    <input type="hidden" id="number" name="number" value="<?php echo $value['phone'] ?>">
                                            <input type="hidden" id="pmdc_no" name="pmdc_no" value="<?php echo $value['pmdc_no'] ?>">
                                                </td>
                                                <td>
                                                    <input type="checkbox" id="rejectlist" name="reject[]" class="btn btn-primary" value="<?php echo $value['pk_id'] ?>">
                                                    <label>Reject</label>

                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    }
                                    ?>

                                </tbody>
                            </table>
                        </form>
                    </div>
                </div>

            </div>
        </div>
        <!-- /.row --> 
    </div>
</div>
<!-- /.container-fluid -->
