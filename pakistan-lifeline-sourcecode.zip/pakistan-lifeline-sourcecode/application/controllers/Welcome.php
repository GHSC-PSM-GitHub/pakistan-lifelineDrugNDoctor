<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('login_model');
        $this->load->model('locations');
        $this->login = new Login_model();
    }

    public function index() {
        $data = array();
        $data['breadcrumb'] = 'Login';
        $data['page_title'] = 'Login';
        $this->load->view('login', $data);
    }
    public function signup()
    {
        $data = array();
        $data['form'] = array();
        $data['pk_id'] = '';
        $data['form']['province'] = 1;
	$data['form']['district'] = 28;
        $location = new locations();
        $data['districts'] = $location->find_by_parent_id($data['form']['province'], 4);
	$data['tehsils'] = $location->find_by_parent_id($data['form']['district'], 5);
        $data['main_content'] = $this->load->view('signup/signup', $data, TRUE);
        $this->load->view('layout/main', $data);
        
    }
    public function save_signup(){
        if($this->input->post()){
            $this->session->set_flashdata('msg', 'Your request for registration has been submitted successfully, please wait till PMDC verification. You will be notified through provided *Mobile Number* & *Email* upon verification.');
            $this->login->create_user();
            $data['number'] = $this->input->post("phone");
            $data['email'] = $this->input->post("email");
            $this->load->view('layout/sms_nih', $data);
            $this->load->view('layout/mail', $data);
             redirect();
        }
    }
    public function pmdc_no_check(){
       $result= $this->login->check_pmdc($this->input->post("pmdc_no"));
       if($result=='true'){
           echo json_encode(true);
       }
       else{
           echo json_encode(false);
       }
    }
    public function login() {

        if ($_POST) {
            $query = $this->login_model->validate_user();

            //-- if valid
            if ($query) {
                $data = array();
                foreach ($query as $row) {
                    $data = array(
                        'user_id' => $row->pk_id,
                        'name' => $row->full_name,
                        'email' => $row->email,
                        'role' => $row->role,
                        'clinic_name' => $row->clinic_name,
                        'address' => $row->address,
                        'pmdcno' => $row->pmdc_no,
                        'is_login' => TRUE
                    );
                    $this->session->set_userdata($data);
//                    print_r($_SESSION);exit;
                }
                if ($_SESSION['role'] == 'D') {
                    $url = base_url('patients/search_patients');
                    redirect($url, 'refresh');
                } else if ($_SESSION['role'] == 'POS') {
                    $url = base_url('pos/search_prescription');
                    redirect($url, 'refresh');
                }
                else if ($_SESSION['role'] == 'P') {
                    $url = base_url('pmdc/pending_approvals_list');
                    redirect($url, 'refresh');
                } else if ($_SESSION['role'] == 'N') {
                    $url = base_url('patients/search_patients');
                    redirect($url, 'refresh');
                } else if ($_SESSION['role'] == 'FD') {
                    $url = base_url('patients/search_patients');
                    redirect($url, 'refresh');
                }
            } else {
                redirect(base_url() . '/', 'refresh');
            }
        } else {
            redirect(base_url() . '/', 'refresh');
        }
        //exit;
    }
    
    
    public function password_reset() {
        
        if ($_POST) {
            $id = $_SESSION['user_id'];
            $query = $this->login_model->validate_user_pass($id);

            //-- if valid
            if ($query) {
                $this->login_model->update_pass($id);
                ?>
                <script>
                    alert("Password Changed Sucessfully");
                </script>
                <?php
                $this->session->sess_destroy();
                redirect(base_url() . '/', 'refresh');
            } else {
                ?>
                <script>
                    alert("You entered wrong old password");
                </script>
                <?php
                redirect(base_url() . '/', 'refresh');
            }
        } else {
            $data = array();
            $data['page_title'] = 'Password Reset';
            $data['main_content'] = $this->load->view('password_reset', $data, TRUE);
        $this->load->view('password_reset', $data);
        }
        //exit;
    }

    function logout() {
        $this->session->sess_destroy();
        $data = array();
        $data['breadcrumb'] = 'Login';
        $data['page_title'] = 'Login';
        /* $data['main_content'] = $this->load->view('auth/index', $data, TRUE); */
        $this->load->view('login', $data);
        redirect('');
    }

}
