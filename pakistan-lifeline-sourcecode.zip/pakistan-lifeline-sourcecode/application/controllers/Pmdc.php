<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pmdc extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('login_model');
        $this->obj = new Login_model();
    }

    public function pending_approvals_list() {
        $search_data = $this->obj->pending_approvals();
//        print_r($search_data);exit;
        if (!empty($search_data)) {
            $data['pending_list'] = $search_data;
        }
        $data['page_title'] = 'Approve Doctors';
        $data['main_content'] = $this->load->view('pmdc/approve_doctors', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function approve_doctors() {
        if (!empty($this->input->post('reject')) && !empty($this->input->post('rejlist'))) {
            $data['reject'] = $this->obj->reject_list($this->input->post("reject"));
            $data['number'] = $this->obj->reject_users($this->input->post("reject"));
            $this->load->view('layout/sms_nih', $data);
            $this->load->view('layout/mail', $data);
        }
        if (!empty($this->input->post('approve')) && !empty($this->input->post('aprovlist'))) {
            $data['approve'] = $this->input->post('approve');
            $data['pmdc_no'] = $this->input->post('pmdc_no');
            $data['number'] = $this->input->post('number');
            $info = $this->obj->new_users($this->input->post("approve"));
            $data['userinfo'] = $info['qres'];
            $data['nursepass'] = $info['nursepass'];
            $data['fdeskpass'] = $info['fdeskpass'];
            $this->load->view('layout/sms_nih', $data);
            $this->load->view('layout/mail', $data);
            $this->obj->approve_list($this->input->post("approve"));
        }
        redirect(base_url() . 'pmdc/pending_approvals_list', 'refresh');
    }

}
