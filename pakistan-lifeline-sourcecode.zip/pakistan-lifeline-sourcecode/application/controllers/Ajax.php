<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Ajax extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('locations');
    }

    public function combo(){
        $id = $_POST["id"];
        $lvl = $_POST['lvl'];
        $location = new locations();

        $result = $location->find_by_parent_id($id,$lvl);
        
        echo "<option value=>Select</option>";
        foreach ($result->result_object() as $row){
            echo "<option value=".$row->pk_id.">".$row->location_name."</option>";
        }
    }
     public function combo_locations(){ 
        $lvl = $_POST['lvl'];
        $location = new locations();

        $result = $location->find_by_location_level($lvl);

        echo "<option value=>Select</option>";
        foreach ($result->result_object() as $row){
            echo "<option value=".$row->pk_id.">".$row->location_name."</option>";
        }
    }

    public function facilities(){
        $id = $_POST["id"];
        $wh = new warehouse();

        $result = $wh->find_by_location_id($id);

        echo "<option value=>Select</option>";
        foreach ($result->result_object() as $row){
            echo "<option value=".$row->pk_id.">".$row->warehouse_name."</option>";
        }
    }
    public function facilities_by_category(){
        $category_id = $_POST["category"];
        $wh = new warehouse();

        $result = $wh->find_by_category(2);

        echo "<option value=>Select</option>";
        foreach ($result->result_object() as $row){
            echo "<option value=".$row->pk_id.">".$row->warehouse_name."</option>";
        }
    }
    public function cities(){
        $id = $_POST["province_id"];
        $city = new Cities();

        $result = $city->find_by_province_id($id);

        echo "<option value=>Select</option>";
        foreach ($result->result_object() as $row){
            echo "<option value=".$row->pk_id.">".$row->city_name."</option>";
        }
    }
    public function find_user_hf(){
        $id = $_POST["user_id"];
        $user = new User();

        $result = $user->find_by_user_id($id);
        foreach ($result->result_object() as $row){
            $wh_id=$row->warehouse_id;
        }
        $warehouse=new Warehouse();
        $result_2=$warehouse->find_by_id($wh_id);
        echo "<option value=>Select</option>";
        foreach ($result_2->result_object() as $row){
            echo "<option value=".$row->pk_id.">".$row->warehouse_name."</option>";
        }
    }
    public function mdm_entities(){
         $id = $_POST["id"];
         $type=$_POST['type'];
         if($type=='warehouse'){
             $wh=new Warehouse();
             $result = $wh->find_by_id($id);
             foreach ($result->result_object() as $row){
                 echo $row->warehouse_name;
             }
         }
         else if($type=='location'){
             $loc= new Locations();
             $result = $loc->find_by_id($id);
             foreach ($result->result_object() as $row){
                 echo $row->location_name;
             }
         }
         else if($type=='patient'){
                $patient= new Patients_model();
             $result = $patient->find_by_id($id);
             foreach ($result->result_object() as $row){
                 echo $row->full_name;
             }
         }
     }
    public function population(){
        $id = $_POST["id"];
        $wh_pop = new warehouse_population();

        $result = $wh_pop->find_by_wh_id($id,date("Y"));
        foreach($result->result_object() as $row) {
            $population = $row->facility_total_pouplation;
            $years1217 = $population*70/100;
            $years18 = $population*23/100;
            $total = $years1217+$years18;
        }
        
        echo '<div class="col-3">
        <div class="form-group">
            <label for="example-text-input-sm" class="col-form-label">Total Population</label>
            <div>
                '.number_format($population).'
            </div>
        </div>
    </div>
    <div class="col-3">
        <div class="form-group">
            <label for="example-text-input-sm" class="col-form-label">Target 12-17 Yrs</label>
            <div>
            '.number_format($years1217).'
            </div>
        </div>
    </div>
    <div class="col-3">
        <div class="form-group">
            <label for="example-text-input-sm" class="col-form-label">Target >=18 Yrs</label>
            <div>
            '.number_format($years18).'
            </div>
        </div>
    </div>
    <div class="col-3">
        <div class="form-group">
            <label for="example-text-input-sm" class="col-form-label">Target Population</label>
            <div>
            '.number_format($total).'
            </div>
        </div>
    </div>';
    }
}