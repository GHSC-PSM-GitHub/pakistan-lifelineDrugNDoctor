<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auth extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->model('login_model'); 
        
    } 
    public function index() {
        $data = array();
        $data['breadcrumb'] = 'Login';
        $data['page_title'] = 'Login';
        /* $data['main_content'] = $this->load->view('auth/index', $data, TRUE); */
        $this->load->view('login', $data);
    }

//    public function login() {
//        $data = array();
//        $data['breadcrumb'] = 'Login';
//        $data['page_title'] = 'Login';
//        $this->load->view('login', $data);
//    }

    /*     * **************Function login**********************************
     * @type            : Function
     * @function name   : log
     * @description     : Authenticatte when uset try lo login. 
     *                    if autheticated redirected to logged in user dashboard.
     *                    Also set some session date for logged in user.   
     * @param           : null 
     * @return          : null 
     * ********************************************************** */

    public function login() {

        if ($_POST) {
            $query = $this->login_model->validate_user();

            //-- if valid
            if ($query) {
                $data = array();
                foreach ($query as $row) {
//                    echo '<pre>';
//                    print_r($row);
//                    echo '</pre>';
//                    exit;
                    $data = array(
                        'id' => $row->pk_id,
                        'name' => $row->username,
                        'email' => $row->email,
                        'role' => $row->role_id, 
                        'is_login' => TRUE
                    );
                    $this->session->set_userdata($data);
                    $role_id = $row->role_id;
                }

                if($this->mobile_detect->isMobile()){
                    $url = base_url('dataentry/index');
                }
                
              $url = base_url('dashboard/index');

                redirect($url, 'refresh');
            } else {
                redirect(base_url() . '/', 'refresh');
            }
        } else {
            redirect(base_url() . '/', 'refresh');
        }
        //exit;
    }

    /*     * ***************Function logout**********************************
     * @type            : Function
     * @function name   : logout
     * @description     : Log Out the logged in user and redirected to Login page  
     * @param           : null 
     * @return          : null 
     * ********************************************************** */

    function logout() {
        $this->session->sess_destroy();
        $data = array();
        $data['breadcrumb'] = 'Login';
        $data['page_title'] = 'Login';
        /* $data['main_content'] = $this->load->view('auth/index', $data, TRUE); */
        $this->load->view('login', $data);
        redirect('');
    }

}