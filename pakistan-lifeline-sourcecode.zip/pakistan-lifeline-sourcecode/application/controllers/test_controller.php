<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class test_controller extends CI_Controller {
    public function __construct() {
        parent::__construct();
//        check_login_user();
        $this->load->model('test_model'); 
        $this->obj = new test_model(); 
    }
    public function display_data()
    {
        $this->obj->find_all();
    }
}