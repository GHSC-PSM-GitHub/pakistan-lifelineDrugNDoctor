<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Pos extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('patients_model');
        $this->load->model('patient_prescription_model');
        $this->load->model('billing_information_model');
        $this->obj = new Patients_model();
        $this->obj_patient_prescription = new Patient_prescription_model();
        $this->obj_billing = new Billing_information_model();
    }

    public function search_prescription() {
        $search_text = $this->input->post("search_text");
        if ($this->input->post("search_text")) {
            $search_data = $this->obj->search_billing_patients($search_text);
        }
        if (!empty($search_data)) {
            $data['searched_data'] = $search_data->result_array();
        }
        else{
             $data['searched_data']='';
        }
        $data['searched_text']=$this->input->post("search_text");
        $data['page_title'] = 'Search Prescription';
        $data['main_content'] = $this->load->view('pos/search_prescription', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function billing() {
        if ($this->input->get("visit_id")) {
            $data_medicines = $this->obj_patient_prescription->find_billing_medicines($this->input->get("visit_id"));
            $data_medicines_array = $data_medicines->result_array();
            $data['patient_medicines_info'] = $data_medicines_array;
        }
        $data['page_title'] = 'Bill Prescription';
        $data['main_content'] = $this->load->view('pos/bill_prescription', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function process_bill() {
//        echo'<pre>';
//        print_r($this->session->userdata());
        $sale_array = $this->input->post("sale_qty");
        $price_array = $this->input->post("price");
        $id_array = $this->input->post("patient_prescription_id");
        if ($this->input->post()) {
            foreach ($id_array as $key => $value) {
                $this->obj_billing->sale_quantity = $sale_array[$key];
                $this->obj_billing->price = $price_array[$key];
                $this->obj_billing->prescription_id = $id_array[$key];
                 $this->obj_billing->total = $this->input->post("total");
                 $this->obj_billing->balance = $this->input->post("balance");
                 $this->obj_billing->paid = $this->input->post("paid");
                $this->obj_billing->visit_id = $this->input->post("visit_id");
                $this->obj_billing->pharmacy_id = $this->session->userdata("user_id");
                $this->obj_billing->save();
                $this->obj_patient_prescription->update_processed_prescriptions($id_array[$key]);
            }
            $data_medicines = $this->obj_billing->find_by_visit_id($this->input->post("visit_id"));
            $data_medicines_array = $data_medicines->result_array();
            $data['patient_medicines_info'] = $data_medicines_array;
        }

        $data['main_content'] = $this->load->view('pos/print_bill', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function print_bill() {
        if ($this->input->get()) {
            $data_medicines = $this->obj_billing->find_by_visit_id($this->input->get("visit_id"));
            $data_medicines_array = $data_medicines->result_array();
            $data['patient_medicines_info'] = $data_medicines_array;
        }
        $data['main_content'] = $this->load->view('pos/print_bill', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function pharmacy_bills() {
        $search_data = $this->obj_billing->search_bills();
        $data['searched_data'] = $search_data->result_array();
        $data['page_title'] = 'Search Prescription';
        $data['main_content'] = $this->load->view('pos/search_bills', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

}
