<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Patients extends CI_Controller {

    public function __construct() {
        parent::__construct();
        check_login_user();
        $this->load->model('patients_model');
        $this->load->model('patient_visits_model');
        $this->load->model('patient_diagnosis_model');
        $this->load->model('patient_tests_model');
        $this->load->model('lab_tests_model');
        $this->load->model('diseases_model');
        $this->load->model('medicines_model');
        $this->load->model('patient_prescription_model');
        $this->load->model('strength_model');
        $this->load->model('dose_model');
        $this->load->model('locations');
        $this->obj = new Patients_model();
        $this->obj_visit = new Patient_visits_model();
        $this->obj_diagnosis = new Diseases_model();
        $this->obj_tests = new Lab_tests_model();
        $this->obj_patient_diagnosis = new Patient_diagnosis_model();
        $this->obj_patient_tests = new Patient_tests_model();
        $this->obj_medicine = new Medicines_model();
        $this->obj_patient_prescription = new Patient_prescription_model();
        $this->obj_strength = new Strength_model();
        $this->obj_dose = new Dose_model();
    }

    public function index() {
        $data = array();
        $location = new locations();
        if ($this->input->get("patient_id")) {
            $data['form'] = array();
            $data['pk_id'] = '';
            $result = $this->obj->find_by_id($this->input->get("patient_id"));
            $patient_array = $result->result_array();
            foreach ($patient_array as $row)
            {
                    $prov_id = $row['province_id'];
                    $dist_id = $row['district_id'];
                    $teh_id = $row['tehsil_id'];
            }
            $data['patient_data'] = $patient_array;
            $data['districts'] = $location->find_by_parent_id($prov_id, 4);
            $data['tehsils'] = $location->find_by_parent_id($dist_id, 5);
            $data['ucs'] = $location->find_by_parent_id($teh_id, 6);
        }
        if ($this->input->get("edit")) {
            $data['edit'] = "true";
        }
        if($_SESSION['role'] == 'FD')
        {
            $data['edit'] = "true";
        }
        $data['form'] = array();
        $data['pk_id'] = '';
        $data['form']['province'] = 1;
	$data['form']['district'] = 28;
        if (empty($this->input->get("patient_id"))) {
            $data['districts'] = $location->find_by_parent_id($data['form']['province'], 4);
            $data['tehsils'] = $location->find_by_parent_id($data['form']['district'], 5);
        }
//        $data['age'] = $this->input->get("age");
        $data['visit_id'] = $this->input->get("visit_id");
        $data['page_title'] = 'Register Patient';
        $data['main_content'] = $this->load->view('patients/register_patient', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add_patient() {
        $data = array();
        if ($this->input->get("visit_id") || $this->input->post("visit_id")) {
            if (!empty($this->input->get("visit_id")))
                $result = $this->obj_visit->find_by_id($this->input->get("visit_id"));
            else {
                $result = $this->obj_visit->find_by_id($this->input->post("visit_id"));
            }
            $visit_array = $result->result_array();
            $data['visit_data'] = $visit_array;
            $data['patient_id'] = $this->input->get("patient_id");
        }
        if ($this->input->post("patient_id")) {
            $this->obj->pk_id = $this->input->post("patient_id");
        }
        if ($this->input->get("patient_id")) {
            $data['patient_id'] = $this->input->get("patient_id");
            $res = $this->obj_visit->find_by_patient_id($this->input->get("patient_id"));
            $row = $res->row();
            if (isset($row) && !empty($row))
            {
                $data['vital_info'] = $res->result_array();
            }
        }
        if (!empty($this->input->post("patient_id_old"))) {
            $data['patient_id'] = $this->input->post("patient_id_old");
            $res = $this->obj_visit->find_by_patient_id($this->input->post("patient_id_old"));
            $row = $res->row();
            if (isset($row) && !empty($row))
            {
                $data['vital_info'] = $res->result_array();
            }
        }
        if (!empty($this->input->post("update_patient_id"))) {
            $this->obj->pk_id = $this->input->post("update_patient_id");
//            $res = $this->obj_visit->find_by_patient_id($this->input->post("update_patient_id"));
//            $row = $res->row();
//            if (isset($row) && !empty($row))
//            {
//                $data['vital_info'] = $res->result_array();
//            }
        }
        if ($this->input->post("full_name") && empty($this->input->post("patient_id_old"))) {
//            $this->obj->patient_id_old = $this->input->post("patient_id_old");
            $this->obj->full_name = ucfirst($this->input->post("full_name"));
            $this->obj->gender = $this->input->post("gender");
            $this->obj->nic_no = $this->input->post("cnic_number");
            $this->obj->mobile_no = $this->input->post("contact_number");
//            $this->obj->age = $this->input->post("age");
            $this->obj->age = $_POST['dob']['2'] . "-" . $_POST['dob']['1'] . "-" . $_POST['dob']['0'];
            $this->obj->email = $this->input->post("email");
            $this->obj->province_id = $this->input->post("province");
            $this->obj->district_id = $this->input->post("district");
            $this->obj->tehsil_id = $this->input->post("tehsil");
            $this->obj->uc_id = $this->input->post("uc");
            $this->obj->created_by = $this->session->userdata("user_id");
            $this->obj->created_date = date("Y-m-d h:i:sa");
            $patient_id = $this->obj->save();
            $data['patient_id'] = $patient_id;
        }
        $data['visit_id'] = $this->input->get("visit_id");
        $data['page_title'] = 'Patient Readings';
        if ($this->input->post("edit")) {
            redirect(base_url("patients/search_patients"));
        } 
        if(empty($patient_id) && empty($this->input->post("patient_id_old")) && empty($this->input->get('patient_id'))){
            $location = new locations();
//            $data['alert_duplicate'] = 'yes';
//            $data['main_content'] = $this->load->view('patients/index');
//            redirect(base_url('patients/index',$data));
//            $this->load->view('layout/main', $data);
//            return $this->load->view('patients/index', $data);
//            if (!$this->cart->contents())
//            {
//            $dat=array();
//            $dat['nam'] = $this->input->post("full_name");
//             $this->session->set_flashdata('message', 'You cant add same info again!');
             $this->session->set_flashdata('full_name', $this->input->post("full_name"));
             $this->session->set_flashdata('contact_number', $this->input->post("contact_number"));
             $this->session->set_flashdata('gender', $this->input->post("gender"));
             $this->session->set_flashdata('cnic_number', $this->input->post("cnic_number"));
             $this->session->set_flashdata('age', $this->input->post("age"));
             $this->session->set_flashdata('email', $this->input->post("email"));
             $this->session->set_flashdata('dob', $this->input->post("dob"));
             $this->session->set_flashdata('prov', $this->input->post("province"));
             $this->session->set_flashdata('dist', $this->input->post("district"));
             $this->session->set_flashdata('teh', $this->input->post("tehsil"));
             $this->session->set_flashdata('uc', $this->input->post("uc"));
//             $data['districts'] = $location->find_by_parent_id($_POST['province'], 4);
//             $data['tehsils'] = $location->find_by_parent_id($_POST['district'], 5);
//             $data['ucs'] = $location->find_by_parent_id($_POST['tehsil'], 6);
             $d = $location->find_by_parent_id($this->input->post("province"), 4);
             $t = $location->find_by_parent_id($this->input->post("district"), 5);
             $u = $location->find_by_parent_id($this->input->post("tehsil"), 6);
//             foreach ($d->result_object() as $row) {
//                 $dst[] = $row->location_name; 
//             }
             $this->session->set_flashdata('districts', $d->result_object());
             $this->session->set_flashdata('tehsils', $t->result_object());
             $this->session->set_flashdata('ucs', $u->result_object());
//             $this->session->set_userdata($dat);
             
//            }
//            $data['message'] = 'Your cart is empty!';
//            $data['main_content'] = $this->load->view('http://localhost:8080/gpapp/patients/index', $data, TRUE);
//            $this->load->view('patients/index', $data);
            redirect($_SERVER['HTTP_REFERER']);
//              redirect('patients/index');
//             $this->load->view('patients/index', $data, TRUE);
//             $this->index();
        }
        else {
            if($_SESSION['role'] == 'N')
            {
                $data['edit'] = "true";
            }
            $data['main_content'] = $this->load->view('patients/patient_readings', $data, TRUE);
            $this->load->view('layout/main', $data);
        }
    }

    public function add_patient_readings() {
        $data = array();
        if ($this->input->get("visit_id") || $this->input->post("visit_id")) {
            if (!empty($this->input->get("visit_id")))
                $result_disease = $this->obj_patient_diagnosis->find_by_visit_id($this->input->get("visit_id"));
            else {
                $result_disease = $this->obj_patient_diagnosis->find_by_visit_id($this->input->post("visit_id"));
            }
            if (!empty($result_disease)) {
                $diagnosis_array = $result_disease->result_array();
                $data['diagnosis_data'] = $diagnosis_array;
            }
            if (!empty($this->input->get("visit_id")))
                $result_test = $this->obj_patient_tests->find_by_visit_id($this->input->get("visit_id"));
            else {
                $result_test = $this->obj_patient_tests->find_by_visit_id($this->input->post("visit_id"));
            }
            if (!empty($result_test)) {
                $test_array = $result_test->result_array();
                $data['test_data'] = $test_array;
            }
            if (!empty($this->input->get("patient_id")) && !empty($this->input->get("visit_id"))) {
                $data['patient_id'] = $this->input->get("patient_id");
                $data['visit_id'] = $this->input->get("visit_id");
            } else {
                $data['patient_id'] = $this->input->post("patient_id");
                $data['visit_id'] = $this->input->post("visit_id");
            }
        }
        if ($this->input->post("visit_id")) {
            $this->obj_visit->pk_id = $this->input->post("visit_id");
        }

        if ($this->input->post()) {
            $this->obj_visit->temperature = $this->input->post("temperature");
            $this->obj_visit->bp_lower = $this->input->post("bp_diastolic");
            $this->obj_visit->bp_upper = $this->input->post("bp_systolic");
            $this->obj_visit->pulse = $this->input->post("heart_pulse");
            $this->obj_visit->other = $this->input->post("notes");
            $this->obj_visit->doctor_id = $this->session->userdata("user_id");
            $this->obj_visit->patient_id = $this->input->post("patient_id");
            $this->obj_visit->visited_on = date("Y-m-d h:i:sa");
            $this->obj_visit->created_at = date("Y-m-d h:i:sa");
            $visit_id = $this->obj_visit->save();
            $data['patient_id'] = $this->input->post("patient_id");
            $data['visit_id'] = $visit_id;
        }
        if ($this->input->post("edit")) {
            redirect(base_url("patients/search_patients"));
        } 
        $disease = $this->obj_diagnosis->find_all();
        $disease_array = $disease->result_array();
        $data['diseases'] = $disease_array;
        $test = $this->obj_tests->find_all();
        $test_array = $test->result_array();
        $data['tests'] = $test_array;
        $data['page_title'] = 'Patient Diagnosis';
        $data['main_content'] = $this->load->view('patients/patient_diagnosis', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add_patient_diagnosis() {

        $data = array();
        if ($this->input->post("visit_id") && $this->input->post("patient_id")) {
            $this->obj_patient_diagnosis->delete($this->input->post("visit_id"));
            $this->obj_patient_tests->delete($this->input->post("visit_id"));
        }
        if ($this->input->post()) {
            $disease_array = $this->input->post('disease');
            if (!empty($disease_array)) {
                foreach ($disease_array as $key => $value) {
//                print_r($value);exit;
                    $this->obj_patient_diagnosis->visit_id = $this->input->post("visit_id");
                    $this->obj_patient_diagnosis->notes = $this->input->post("notes");
                    $this->obj_patient_diagnosis->diagnosis_id = $value;
                    $this->obj_patient_diagnosis->created_at = date("Y-m-d h:i:sa");
                    $this->obj_patient_diagnosis->save();
                }
            }
            $test_array = $this->input->post('tests');
            if (!empty($test_array)) {
                foreach ($test_array as $key => $value) {
                    $this->obj_patient_tests->visit_id = $this->input->post("visit_id");
                    $this->obj_patient_tests->notes = $this->input->post("notes");
                    $this->obj_patient_tests->test_id = $value;
                    $this->obj_patient_tests->created_at = date("Y-m-d h:i:sa");
                    $this->obj_patient_tests->save();
                }
            }
            $data['patient_id'] = $this->input->post("patient_id");
            $data['visit_id'] = $this->input->post("visit_id");
        }
        $medicines = $this->obj_medicine->find_all();
        $medicine_array = $medicines->result_array();
        $data['medicines'] = $medicine_array;
        $strength = $this->obj_strength->find_all();
        $strength_array = $strength->result_array();
        $data['strength'] = $strength_array;
        $dose = $this->obj_dose->find_all();
        $dose_array = $dose->result_array();
        $data['dose'] = $dose_array;
        $data['page_title'] = 'Patient Prescription';
        $data['main_content'] = $this->load->view('patients/prescribe_medicines', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function add_medicines() {
        if ($this->input->post("visit_id")) {
            if ($this->input->post("days")) {
                $this->obj_patient_prescription->visit_id = $this->input->post("visit_id");
                $this->obj_patient_prescription->medicine_id = $this->input->post("medicine");
                $this->obj_patient_prescription->dose = $this->input->post("dose_form");
                $this->obj_patient_prescription->strength = $this->input->post("strength");
                $this->obj_patient_prescription->repetition = $this->input->post("method");
                $this->obj_patient_prescription->days = $this->input->post("days");
                $this->obj_patient_prescription->notes = $this->input->post("notes");
                $this->obj_patient_prescription->contradict_msg = $this->input->post("contradict_msg");
                $this->obj_patient_prescription->created_at = date("Y-m-d h:i:sa");
                $this->obj_patient_prescription->processed = 0;
                $prescription_id = $this->obj_patient_prescription->save();
            }
            $prescribed_medicines = $this->obj_patient_prescription->find_by_visit_id($this->input->post("visit_id"));
            $prescription_array = $prescribed_medicines->result_array();
            $body = "";
            $medicine_string = ',';
//            print_r($prescription_array);exit;
            foreach ($prescription_array as $key => $value) {
                $medicine_string .= $value['medicine_id'] . ",";
                $body .= "<tr>";
                $body .= "<td>" . $value['generic_name'] . "</td>";
                $body .= "<td>" . $value['dose'] . "</td>";
                $body .= "<td>" . $value['strength'] . "</td>";
                $body .= "<td>" . $value['repetition'] . "</td>";
                $body .= "<td>" . $value['days'] . "</td>";
                $body .= "<td><button class='btn btn-warning' name='delete_btn' id='delete_btn' data-id='" . $value['pk_id'] . "' data-visit-id='" . $this->input->post("visit_id") . "'>Delete</button></td>";
                $body .= "<td style='color: #2F96B4;font-size: 12px;width:300px;'>" . $value['contradict_msg'] . "</td>";
                $body .= "</tr>";
            }
            $json_array['body'] = $body;
            $json_array['medicine_string'] = rtrim($medicine_string, ',');
            echo json_encode($json_array);
        }
    }

    public function print_prescription() {
        $data = array();
        if ($this->input->get("patient_id")) {
            $data_patient = $this->obj->find_by_id($this->input->get("patient_id"));
            $data_array = $data_patient->result_array();
            $data['patient_info'] = $data_array;
        }

        if ($this->input->get("visit_id")) {
            $data_visit = $this->obj_visit->find_by_id($this->input->get("visit_id"));
            $data_visit_array = $data_visit->result_array();
            $data['patient_visit_info'] = $data_visit_array;
        }

        if ($this->input->get("visit_id")) {
            $data_diagnosis = $this->obj_patient_diagnosis->find_diagnosed_diseases($this->input->get("visit_id"));
//            print_r($data_diagnosis);
//            $row = $data_diagnosis->row();
            if (isset($data_diagnosis) && !empty($data_diagnosis))
            {
                $data_diagnosis_array = $data_diagnosis->result_array();
                $data['patient_diagnosis_info'] = $data_diagnosis_array;
            }
        }

        if ($this->input->get("visit_id")) {
            $data_tests_array = array();
            $data_tests = $this->obj_patient_tests->find_recommeded_tests($this->input->get("visit_id"));
            if (!empty($data_tests)) {
                $data_tests_array = $data_tests->result_array();
            }
            $data['patient_test_info'] = $data_tests_array;
        }

        if ($this->input->get("visit_id")) {
            $data_medicines = $this->obj_patient_prescription->find_prescribed_medicines($this->input->get("visit_id"));
            if (isset($data_medicines) && !empty($data_medicines))
            {
                $data_medicines_array = $data_medicines->result_array();
                $data['patient_medicines_info'] = $data_medicines_array;
            }
        }

//        print_r($data);exit;
        $data['page_title'] = 'Patient Prescription';
        $data['main_content'] = $this->load->view('patients/print_prescription', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function get_info(){
        $data['name'] = $_POST['name'];
        $data['phone'] = $_POST['phone'];
        $search_data = $this->obj->get_info($_POST['phone'],$_POST['name']);
        if (!empty($search_data))
            $data['searched_data'] = $search_data->result_array();
        $data['page_title'] = 'Search Patients';
        $this->load->view('patients/get_info', $data);
    }

    public function search_patients() {
        $search_text_mr = $this->input->post("search_text_mr");
        $search_text_contact = $this->input->post("search_text_contact");
        if ($this->input->post("search_text_mr") || $this->input->post("search_text_contact")) {
            $search_data = $this->obj->search_patients($search_text_mr,$search_text_contact);
        }
        if (!empty($search_data)) {
            $data['searched_data'] = $search_data->result_array();
        }
        else{
             $data['searched_data']='';
        }
        $data['searched_text_mr']=$this->input->post("search_text_mr");
        $data['searched_text_contact']=$this->input->post("search_text_contact");
//        $data['page_title'] = 'Search Prescription';
//        $data['main_content'] = $this->load->view('pos/search_prescription', $data, TRUE);
//        $this->load->view('layout/main', $data);
        
        $data['page_title'] = 'Search Patients';
        $data['main_content'] = $this->load->view('patients/search_patients', $data, TRUE);
        $this->load->view('layout/main', $data);
    }

    public function contradictory_products() {
        if ($this->input->post('medicine_id')) {
            $contradicts = $this->obj_medicine->contradict_message($this->input->post('contrasting_medicine'),$this->input->post('medicine_id'));
            if (!empty($contradicts)) {
                $contradicts_array = $contradicts->result_array();
                $count = 0;
                foreach ($contradicts_array as $key => $value) {
                    $var_array[$count]['contradictory_product_name'] = $value['contrast_product_name'];
                    $var_array[$count]['message'] = $value['remarks'];
                    $count++;
                }
                $json_array['message_array'] = $var_array;
                echo json_encode($json_array);
//                echo json_encode('saad');
            }
            else{
                $json_array['message_array'] = ["empty"];
                echo json_encode($json_array);
            }
        }
    }

    public function remove_already_selected() {
        $medicines = $this->obj_medicine->remove_selected_medicine($this->input->post('medicine_id'));
        $medicine_array = $medicines->result_array();
        $med_array = array();

        foreach ($medicine_array as $key => $value) {
            $med_array[$value['pk_id']] = $value['generic_name'];
        }
        $json_array['medicine_array'] = $med_array;
        echo json_encode($json_array);
    }

    public function contradictory_products_old() {
        if ($this->input->post('medicine_id')) {
            $medicines = $this->obj_medicine->contradict_message($this->input->post('medicine_id'));
            $medicine_array = $medicines->result_array();
            ?>
            <option value="">Select</option>
            <?php
            foreach ($medicine_array as $key => $value) {
                ?>
                <option value="<?php echo $value['pk_id'] ?>"> <?php echo $value['generic_name']; ?></option>
                <?php
            }
        }
    }

    public function delete_prescribed_medicines() {
        $this->obj_patient_prescription->delete_medicine($this->input->post("id"));
    }

    public function get_medicine_strength() {
        $strength = $this->obj_strength->get_specified_strength($this->input->post("medicine_id"));
        if (!empty($strength)) {
            $strength_array = $strength->result_array();
            ?>
            <!--<option value="">Select</option>-->
            <?php
            foreach ($strength_array as $key => $value) {
                ?>
                <option value="<?php echo $value['strength'] ?>"> <?php echo $value['strength']; ?></option>
                <?php
            }
        } else {
            $strength = $this->obj_strength->find_all();
            $strength_array = $strength->result_array();
            ?>
            <option value="">Select</option>
            <?php
            foreach ($strength_array as $key => $value) {
                ?>
                <option value="<?php echo $value['strength'] ?>"> <?php echo $value['strength']; ?></option>
                <?php
            }
        }
    }

    public function get_medicine_dose() {
        $dose = $this->obj_dose->get_specified_dose($this->input->post("medicine_id"));
        if (!empty($dose)) {
            $dose_array = $dose->result_array();
            ?>
            <!--<option value="">Select</option>-->
            <?php
            foreach ($dose_array as $key => $value) {
                ?>
                <option value="<?php echo $value['dose'] ?>"> <?php echo $value['dose']; ?></option>
                <?php
            }
        } else {
            $dose = $this->obj_dose->find_all();
            $dose_array = $dose->result_array();
            ?>
            <option value="">Select</option>
            <?php
            foreach ($dose_array as $key => $value) {
                ?>
                <option value="<?php echo $value['dose_form'] ?>"> <?php echo $value['dose_form']; ?></option>
                <?php
            }
        }
    }

}
