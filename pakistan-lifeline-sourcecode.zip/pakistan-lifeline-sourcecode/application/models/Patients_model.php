<?php

class Patients_model extends Base_model {

    // table name
    protected static $table_name = "patients";
    // db connection
    private $conn;
    //db fileds
    protected static $db_fields = array("full_name", "gender", "nic_no", "mobile_no", "created_date", "created_by", "email", "age","province_id","district_id","tehsil_id","uc_id");
    public $pk_id;
    public $full_name;
    public $gender;
    public $nic_no;
    public $mobile_no;
    public $created_date;
    public $created_by;
    public $email;
    public $age;
    public $province_id;
    public $district_id;
    public $tehsil_id;
    public $uc_id;

    /**
     * 
     * find_all
     * @return type
     * 
     * 
     */
    public function find_all() {
        $qry = "SELECT * FROM " . static::$table_name;
//        print_r($qry);exit;
        return $this->query($qry);
    }

    public function find_by_id($id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE pk_id=" . $id;
        return $this->query($qry);
    }

    public function check_unique_cnic($cnic) {

        $qry = "SELECT count(*) as cnt FROM " . static::$table_name;
        $qry .= " WHERE nic_no='" . $cnic . "' ";
        $query = $this->query($qry);
        $qq = $query->row_array();
        if ($qq['cnt'] > 0) {
            return 'no'; //not unique
        } else {
            return 'yes'; //yes its unique
        }
    }

    public function find_by($by, $text) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE $by like '%" . $text . "%' ";
//        echo $qry;exit;
        return $this->query($qry);
    }

    public function get_info($text,$name) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE mobile_no = '" . $text . "' ORDER BY full_name";
//         AND full_name LIKE '%" . $name . "%'
//        echo $qry;
        return $this->query($qry);
    }
    

    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                $attributes[$field] = $this->$field;
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save() {
        // A new record won't have an id yet.
        return isset($this->pk_id) ? $this->update() : $this->create();
    }

    public function deactivate($id) {
        $qry = "UPDATE " . static::$table_name . " SET is_active=0 where wh_id=$id";
        $this->query2($qry);
    }

    /**
     * create
     * @global type $this
     * @return boolean
     */
    public function create() {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $query = null; //emptying in case 
        $a = $this->attributes();
//        foreach ($this->attributes() as $key => $value) {
//            print_r($this->attributes());
//            print_r($a['full_name']);
////            $clean_attributes[]=$key[0] = $this->escape_value($value);
//        }
//        $id   = $_POST['id']; //getting from post value
//        $name = $_POST['name'];
//        print_r($clean_attributes);
        $query = $this->db->get_where('patients', array(//making selection
            'full_name' => $a['full_name'],
            'mobile_no' => $a['mobile_no'],
        ));
//        echo $query;
        $count = $query->num_rows(); //counting result from query

        if ($count === 0) {
        
            $attributes = $this->sanitized_attributes();

            $sql = "INSERT INTO " . static::$table_name . " (";
            $sql .= join(", ", array_keys($attributes));
            $sql .= ") VALUES ('";
            $sql .= join("', '", array_values($attributes));
            $sql .= "')";
            //echo $sql;exit;
            if ($this->query2($sql)) {
                return $this->insert_id();
            } else {
                return false;
            }
        }
        else{
            return false;
        }
    }

    /**
     * update
     * @global type $this
     * @return type
     */
    public function update() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $query = null; //emptying in case 
        $a = $this->attributes();
//        print_r($this->pk_id);
//        $query = $this->db->get_where('patients', array(//making selection
//            'full_name' => $a['full_name'],
//            'mobile_no' => $a['mobile_no'],
//        ));
//        $this->db->where_not_in('pk_id', $this->pk_id);
//        $query = array('name1', 'name2', 'name3');
//        $this->db->from('tbl_user');
//        $this->db->where('status !=', $status);
//        $this->db->or_where_not_in('username', $names);
//        $query .= $this->db->where_not_in('pk_id', $this->pk_id);
//        echo $query;
        $this->db->select('*');
        $this->db->from('patients');
        $this->db->where('full_name' , $a['full_name']);
        $this->db->where('mobile_no' , $a['mobile_no']);
        $this->db->where_not_in('pk_id', $this->pk_id);
        $query=$this->db->get();
//        print_r($this->db->last_query());    
        $count = $query->num_rows(); //counting result from query
        if ($count === 0) {
        
            $attributes = $this->sanitized_attributes();
            $attribute_pairs = array();
            foreach ($attributes as $key => $value) {
                $attribute_pairs[] = "{$key}='{$value}'";
            }
            $sql = "UPDATE " . static::$table_name . " SET ";
            $sql .= join(", ", $attribute_pairs);
            $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
            $this->query2($sql);
            return $this->pk_id;
        }
        else{
//            $this->load->view('patients/index');
        }
    }

    public function search_patients($search_text_mr,$search_text_contact) {
        $mrcon = '';
        if(isset($search_text_mr) && !empty($search_text_mr))
        {
            $mrcon = "patients.pk_id =  '" . $search_text_mr ."'";
        }
        if(isset($search_text_contact) && !empty($search_text_contact) && empty($search_text_mr))
        {
            $mrcon .= "patients.mobile_no = '" . $search_text_contact ."'";
        }
        if(isset($search_text_contact) && !empty($search_text_contact) && !empty($search_text_mr))
        {
            $mrcon .= "AND patients.mobile_no = '" . $search_text_contact ."'";
        }
        $qry = "SELECT
        patients.full_name,
        patients.gender,
        patients.nic_no,
        patients.mobile_no,
        DATE_FORMAT(patient_visits.visited_on,'%d-%m-%Y') as visiting_date,
        patients.pk_id as patient_id,
        patient_visits.pk_id as visit_id
        FROM
        patients
        LEFT JOIN patient_visits ON patients.pk_id = patient_visits.patient_id
        WHERE
                $mrcon";
//        echo $qry;exit;
        return $this->query($qry);
        
//          (patient_visits.doctor_id =" . $this->session->userdata("user_id") .
//                " OR patients.created_by=" . $this->session->userdata("user_id").")
    }

    public function search_billing_patients($search_text) {
        $filter = '';
        if ((strtoupper(substr($search_text, 0, 2))) == 'PR') {
            $filter = "visit_id=" . substr($search_text, 3) . " OR";
        } else if ((strtoupper(substr($search_text, 0, 2))) == 'MR') {
            $filter .= "patient_id=" . substr($search_text, 3) . " OR";
        }
        $qry = "SELECT DISTINCT
        patients.full_name,
        patients.gender,
        patients.nic_no,
        patients.mobile_no,
        DATE_FORMAT(
                        patient_visits.visited_on,
                        '%d-%m-%Y'
                ) AS visiting_date,
        patients.pk_id AS patient_id,
        patient_visits.pk_id AS visit_id,
        patient_prescription.processed
        FROM
        patients
        INNER JOIN patient_visits ON patients.pk_id = patient_visits.patient_id
        INNER JOIN patient_prescription ON patient_visits.pk_id = patient_prescription.visit_id
        WHERE processed=0
        AND (
        $filter
        mobile_no = '$search_text' OR
        nic_no = '$search_text'
)
        ";
//        print_r($qry);exit;
        return $this->query($qry);
    }

}
