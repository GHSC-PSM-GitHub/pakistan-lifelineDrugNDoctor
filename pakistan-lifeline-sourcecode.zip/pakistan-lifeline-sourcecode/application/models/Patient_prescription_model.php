<?php

class Patient_prescription_model extends Base_model {

    // table name
    protected static $table_name = "patient_prescription";
    // db connection
    private $conn;
    //db fileds
    protected static $db_fields = array("visit_id", "medicine_id", "dose", "strength", "repetition", "days", "notes", "created_at", "processed","contradict_msg");
    public $pk_id;
    public $visit_id;
    public $medicine_id;
    public $dose;
    public $strength;
    public $repetition;
    public $notes;
    public $created_at;
    public $processed;
    public $days;
    public $contradict_msg;

    /**
     * 
     * find_all
     * @return type
     * 
     * 
     */
    public function find_all() {
        $qry = "SELECT * FROM " . static::$table_name;
//        print_r($qry);exit;
        return $this->query($qry);
    }

    public function find_by_id($id) {
        $qry = "SELECT * FROM " . static::$table_name;
        $qry .= " WHERE pk_id=" . $id;
        return $this->query($qry);
    }

    public function find_prescribed_medicines($id) {
        $qry = "SELECT
        medicines.generic_name,
        patient_prescription.pk_id,
        patient_prescription.visit_id,
        patient_prescription.medicine_id,
        patient_prescription.dose,
        patient_prescription.strength,
        patient_prescription.days,
        patient_prescription.repetition, 
        patient_prescription.notes,
        patient_prescription.created_at,
        patient_prescription.processed
        FROM
        patient_prescription
        INNER JOIN medicines ON patient_prescription.medicine_id = medicines.pk_id
        ";
        $qry .= " WHERE visit_id=" . $id;
//        print_r($qry);exit;
        return $this->query($qry);
    }

    public function find_billing_medicines($id) {
        $qry = "SELECT
        medicines.generic_name,
        patient_prescription.pk_id,
        patient_prescription.visit_id,
        patient_prescription.medicine_id,
        patient_prescription.dose,
        patient_prescription.strength,
        patient_prescription.days,
        patient_prescription.repetition, 
        patient_prescription.notes,
        patient_prescription.created_at,
        patient_prescription.processed
        FROM
        patient_prescription
        INNER JOIN medicines ON patient_prescription.medicine_id = medicines.pk_id
        ";
        $qry .= " WHERE visit_id=" . $id;
        $qry .= " AND processed='0'";
//        print_r($qry);exit;
        return $this->query($qry);
    }

    public function find_by_visit_id($visit_id) {
        $qry = "SELECT
        patient_prescription.pk_id,
        patient_prescription.visit_id,
        patient_prescription.medicine_id,
        patient_prescription.dose,
        patient_prescription.strength,
        patient_prescription.days,
        patient_prescription.repetition,
        patient_prescription.quantity,
        patient_prescription.price,
        patient_prescription.amount,
        patient_prescription.notes,
        patient_prescription.created_at,
        patient_prescription.processed,
        patient_prescription.contradict_msg,
        medicines.generic_name
        FROM
                patient_prescription
        INNER JOIN medicines ON patient_prescription.medicine_id = medicines.pk_id";
        $qry .= " WHERE visit_id =$visit_id";
//        echo $qry;exit;
        return $this->query($qry);
    }

    private function instantiate($record) {
        // Could check that $record exists and is an array
        $object = new self;
        // Simple, long - form approach:
        // More dynamic, short - form approach:
        foreach ($record as $attribute => $value) {
            if ($object->has_attribute($attribute)) {
                $object->$attribute = $value;
            }
        }
        return $object;
    }

    /**
     * 
     * has_attribute
     * @param type $attribute
     * @return type
     * 
     * 
     */
    private function has_attribute($attribute) {
        // We don't care about the value, we just want to know if the key exists
        // Will return true or false
        return array_key_exists($attribute, $this->attributes());
    }

    /**
     * 
     * attributes
     * @return type
     * 
     * 
     */
    protected function attributes() {
        // return an array of attribute names and their values
        $attributes = array();
        foreach (static::$db_fields as $field) {
            if (property_exists($this, $field)) {
                $attributes[$field] = $this->$field;
            }
        }
        return $attributes;
    }

    /**
     * 
     * sanitized_attributes
     * @global type $this
     * @return type
     * 
     * 
     */
    protected function sanitized_attributes() {
        $clean_attributes = array();
        // sanitize the values before submitting
        // Note: does not alter the actual value of each attribute
        foreach ($this->attributes() as $key => $value) {
            $clean_attributes[$key] = $this->escape_value($value);
        }
        return $clean_attributes;
    }

    /**
     * 
     * save
     * @return type
     * 
     * 
     */
    public function save() {
        // A new record won't have an id yet.
        return isset($this->pk_id) ? $this->update() : $this->create();
    }

    /**
     * create
     * @global type $this
     * @return boolean
     */
    public function create() {
        // Don't forget your SQL syntax and good habits:
        // - INSERT INTO table (key, key) VALUES ('value', 'value')
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();

        $sql = "INSERT INTO " . static::$table_name . " (";
        $sql .= join(", ", array_keys($attributes));
        $sql .= ") VALUES ('";
        $sql .= join("', '", array_values($attributes));
        $sql .= "')";
//        echo $sql;exit;
        if ($this->query2($sql)) {
            return $this->insert_id();
        } else {
            return false;
        }
    }

    /**
     * update
     * @global type $this
     * @return type
     */
    public function update() {
        // Don't forget your SQL syntax and good habits:
        // - UPDATE table SET key = 'value', key = 'value' WHERE condition
        // - single - quotes around all values
        // - escape all values to prevent SQL injection
        $attributes = $this->sanitized_attributes();
        $attribute_pairs = array();
        foreach ($attributes as $key => $value) {
            $attribute_pairs[] = "{$key}='{$value}'";
        }
        $sql = "UPDATE " . static::$table_name . " SET ";
        $sql .= join(", ", $attribute_pairs);
        $sql .= " WHERE pk_id=" . $this->escape_value($this->pk_id);
        $this->query2($sql);
        return $this->pk_id;
    }

    public function update_processed_prescriptions($prescription_id) {
        $qry = "UPDATE patient_prescription SET processed='1' where pk_id=$prescription_id";
        $this->query($qry);
    }

    public function delete_medicine($id) {
        $qry = "DELETE FROM patient_prescription where pk_id=$id";
        return $this->query($qry);
    }

}
