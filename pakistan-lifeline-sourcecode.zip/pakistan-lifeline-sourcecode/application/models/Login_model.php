<?php

class Login_model extends Base_model {

    public function edit_option_md5($action, $id, $table) {
        $this->db->where('md5(id)', $id);
        $this->db->update($table, $action);
        return;
    }

    public function create_user() {
        $qry = "INSERT INTO users(full_name,pmdc_no,phone,email,clinic_name,address,password,province_id,district_id,tehsil_id,uc_id,cnic_no)";
        $qry .= "VALUES('" . $this->input->post("full_name") . "','" . $this->input->post("pmdc_no") . "','" . $this->input->post("phone") . "','" . $this->input->post("email") . "','" . $this->input->post("clinic_name") . "','" . $this->input->post("address") . "','" . md5($this->input->post("password")) . "','" . $this->input->post("province") . "','" . $this->input->post("district") . "','" . $this->input->post("tehsil") . "','" . $this->input->post("uc") . "','" . $this->input->post("cnic_number") . "')";
        $this->query($qry);
    }

    public function check_pmdc($pmdc_no) {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('pmdc_no', $pmdc_no);
        $this->db->limit(1);
        $query = $this->db->get();
        if ($query->num_rows() == 0) {
            return true;
        } else {
            return false;
        }
    }

    //-- check post email
    public function check_email($email) {
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('email', $email);
        $this->db->limit(1);
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            return $query->result();
        } else {
            return false;
        }
    }

    //check valid user by id
    public function validate_id($id) {
        $this->db->select('*');
        $this->db->from('user');
        $this->db->where('md5(id)', $id);
        $this->db->limit(1);
        $query = $this->db->get();
        if ($query->num_rows() == 1) {
            return $query->result();
        } else {
            return false;
        }
    }

    //-- check valid user
    function validate_user() {

        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('pmdc_no', $this->input->post('username'));
        $this->db->where('password', md5($this->input->post('password')));
        $this->db->where('status', '1');
        $this->db->limit(1);
        $query = $this->db->get();
//        print_r($this->db->get());exit;
        if ($query->num_rows() == 1) {
            return $query->result();
        } else {
            return false;
        }
    }
    function validate_user_pass($id) {

        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('password', md5($this->input->post('old_password')));
        $this->db->where('pk_id', $id);
        $this->db->limit(1);
        $query = $this->db->get();
//        print_r($this->db->get());exit;
        if ($query->num_rows() == 1) {
            return $query->result();
        } else {
            return false;
        }
    }

    function update_pass($id) {
       $qry = "UPDATE users SET password='".md5($this->input->post('new_password'))."' WHERE pk_id = $id";
        $this->query($qry);
    }
    
    function pending_approvals() {
        $this->db->select("*");
        $this->db->from('users');
        $this->db->where('status', 0);
        $this->db->where('role', 'D');
        $query = $this->db->get();
        return $query->result_array();
    }

    function approve_list($list) {
        $qry = "UPDATE users SET status=1 WHERE pk_id IN(" . implode($list, ',') . ")";
//        print_r($qry);exit;
        return $this->db->query($qry);
    }
    function reject_list($list) {
        $qry = "UPDATE users SET role='reject' WHERE pk_id IN(" . implode($list, ',') . ")";
//        print_r($qry);exit;
        return $this->db->query($qry);
    }
    public function new_users($list) {
        $qry = $this->db->query("SELECT * FROM users WHERE pk_id IN(" . implode($list, ',') . ")");
//        print_r($qry);
        foreach ($qry->result() as $row)
        {
               $res[] = $row;
        }
//        exit;
//        for($i=1;$i<=$qry->num_rows();++$i){
////      $data[$i]['task'] = $qry->row($i)->task;
////      $data[$i]['subject_id'] = $qry->row($i)->subject_id;
////      $data[$i]['postdate'] = $qry->row($i)->postdate;
////      $data[$i]['cdate'] = $qry->row($i)->cdate;
//            
//   }
//        $info[] = $this->db->query($qry)->row();
//        print_r($info);
//        exit;
//        $info = $this->db->query($qry);
        $nursepass = $this->pmdc_nurse($qry);
        $fdeskpass = $this->pmdc_fdesk($qry);
//        return $res;
        return array(
            'qres' => $res,
            'nursepass' => $nursepass,
            'fdeskpass' => $fdeskpass,
        );
    }
    public function pmdc_nurse($qry) {
        if ($qry->num_rows() > 0)
        {
           foreach ($qry->result() as $info)
           {
        $password = $this->randomPassword();
        $qry = "INSERT INTO users(full_name,pmdc_no,phone,email,clinic_name,address,password,province_id,district_id,tehsil_id,uc_id,cnic_no,role,status,pmdc_no_id)";
        $qry .= "VALUES('" . $info->pmdc_no .'_nurse' . "','" . $info->pmdc_no . '_nurse' . "','" . $info->phone . "','" . $info->email . "','" . $info->clinic_name . "','" . $info->address . "','" . md5($password) . "','" . $info->province_id . "','" . $info->district_id . "','" . $info->tehsil_id . "','" . $info->uc_id . "','" . $info->cnic_no . "','" . 'N' . "','" . '1' . "','" . $info->pmdc_no . "')";
        $this->query($qry);
        $pass[] = $password;
           }
        }
        return $pass;
    }
    
    public function pmdc_fdesk($qry) {
        if ($qry->num_rows() > 0)
        {
           foreach ($qry->result() as $info)
           {
        $password = $this->randomPassword();
        $qry = "INSERT INTO users(full_name,pmdc_no,phone,email,clinic_name,address,password,province_id,district_id,tehsil_id,uc_id,cnic_no,role,status,pmdc_no_id)";
        $qry .= "VALUES('" . $info->pmdc_no . "_fdesk" . "','" . $info->pmdc_no . "_fdesk" . "','" . $info->phone . "','" . $info->email . "','" . $info->clinic_name . "','" . $info->address . "','" . md5($password) . "','" . $info->province_id . "','" . $info->district_id . "','" . $info->tehsil_id . "','" . $info->uc_id . "','" . $info->cnic_no . "','" . 'FD' . "','" . '1' . "','" . $info->pmdc_no . "')";
        $this->query($qry);
        $pass[] = $password;
           }
        }
        return $pass;
    }
    public function randomPassword() {
            $alphabet = "abcdefghijklmnopqrstuwxyzABCDEFGHIJKLMNOPQRSTUWXYZ0123456789";
            $pass = array(); //remember to declare $pass as an array
            $alphaLength = strlen($alphabet) - 1; //put the length -1 in cache
            for ($i = 0; $i < 8; $i++) {
                $n = rand(0, $alphaLength);
                $pass[] = $alphabet[$n];
            }
            return implode($pass); //turn the array into a string
        }
    public function reject_users($list) {
        $qry = $this->db->query("SELECT * FROM users WHERE pk_id IN(" . implode($list, ',') . ")");
//        print_r($qry);
        foreach ($qry->result() as $row)
        {
               $res[] = $row;
        }
        return $res;
    }
}
