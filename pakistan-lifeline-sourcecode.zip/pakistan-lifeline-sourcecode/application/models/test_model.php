<?php
class test_model extends Base_model {

    public function find_all() { 
        $this->db->select('s.*'); //select s.*
        $this->db->select('f.name as facility_name'); //f.name as facility_name,
        $this->db->select('c.name as country_name'); //c.name as country_name
        $this->db->from('form_1 s'); // from form1 as s
        $this->db->join('facilities f','s.facility_id=f.pk_id','INNER'); // INNER JOIN facilities f ON s.facility_id=f.pk_id
        $this->db->join('country c','f.country_id=c.id','INNER');
        $this->db->where('s.user_id',$user_id); // where s.user_id=12
        $this->db->order_by('s.pk_id','ASC'); // ORDER BY s.pk_id ASC
        $query = $this->db->get();
        $return_arr = $query->result_array();
    }
 

}
